// ════════════════════════════════════════════════════════════
// CDI Mio 5TF - v4.0 SERIAL TUNING EDITION
//
// TAMBAHAN dari v3.1:
//  ✅ UART Serial 9600 baud (HC-05 / USB OTG)
//  ✅ Config tersimpan di EEPROM (tidak hilang saat mati)
//  ✅ RPM Limiter yang bisa diatur
//  ✅ Pulser angle adjustable (50-95°)
//  ✅ Advance map bisa diedit via app
//  ✅ RPM dikirim ke app setiap 8 spark
//
// PROTOKOL SERIAL:
//   App → CDI:
//     GET         → minta semua config
//     SAVE        → simpan config ke EEPROM
//     LIM:12000   → set RPM limiter
//     ANG:82      → set pulser angle
//     MAP:0,8,15,...  → set advance map (32 nilai)
//   CDI → App:
//     RPM:5500    → RPM saat ini (otomatis tiap 8 spark)
//     MAP:0,8,... → advance map
//     LIM:12000   → RPM limiter
//     ANG:82      → pulser angle
//     OK          → perintah diterima
//     ERR         → perintah error
//
// PIN:
//   PD2 (D2)  → Pulser input (INT0, falling edge)
//   PB1 (D9)  → SCR output
//   PB5 (D13) → LED indicator
//   PD0 (D0)  → UART RX (dari HC-05 TX / USB-Serial TX)
//   PD1 (D1)  → UART TX (ke HC-05 RX / USB-Serial RX)
// ════════════════════════════════════════════════════════════

#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <string.h>
#include <stdlib.h>

// ─── Konstanta ────────────────────────────────────────────
#define MAP_SIZE      32
#define SCR_PULSE     1000
#define MAX_FIRE_TICK 64000
#define BAUD_RATE     9600UL
#define UBRR_VAL      ((F_CPU / (16UL * BAUD_RATE)) - 1)
#define SERIAL_BUF    128
#define EEPROM_MAGIC  0xCD

// ─── Config Structure ─────────────────────────────────────
typedef struct {
  uint8_t  advance_map[32]; // Advance per RPM band (0-45 derajat)
  uint16_t rpm_limiter;     // Batas RPM (contoh: 12000)
  uint8_t  pulser_angle;    // Sudut pulser (contoh: 82°)
  uint8_t  checksum;        // XOR checksum
} CDI_Config;

// Default config (sesuai v3.1 original)
const CDI_Config DEFAULT_CONFIG PROGMEM = {
  {0, 8, 15, 20, 24, 28, 30, 32,  // 0-3500 RPM
   34,34, 34, 34, 34, 34, 34, 34, // 4000-7500 RPM
   34,34, 34, 34, 34, 32, 30, 27, // 8000-11500 RPM
   23,19, 17, 15, 15, 15, 10, 10},// 12000-15500 RPM
  12000,  // RPM limiter default
  82,     // Pulser angle default
  0       // Checksum (dihitung saat load)
};

// Config aktif di RAM
CDI_Config cfg;

// EEPROM storage
uint8_t    EEMEM eeprom_magic = 0x00;
CDI_Config EEMEM eeprom_cfg;

// ─── Angle Factor LUT (0-95°) ─────────────────────────────
// factor[n] = (n * 65536) / 360
// Extended sampai 95° untuk mendukung pulser_angle adjustable
const uint16_t angle_factor[96] PROGMEM = {
  0,    182,  364,  546,  728,  910,  1092, 1274,
  1456, 1638, 1820, 2002, 2184, 2366, 2548, 2730,
  2912, 3094, 3276, 3458, 3640, 3822, 4004, 4186,
  4368, 4550, 4732, 4914, 5096, 5278, 5460, 5642,
  5824, 6006, 6188, 6370, 6552, 6734, 6916, 7098,
  7280, 7462, 7644, 7826, 8008, 8190, 8372, 8554,
  8736, 8918, 9100, 9282, 9464, 9646, 9828, 10010,
  10192,10374,10556,10738,10920,11102,11284,11466,
  11648,11830,12012,12194,12376,12558,12740,12922,
  13104,13286,13468,13650,13832,14014,14196,14378,
  14560,14742,14924,15106,15288,15470,15652,15834,
  16016,16198,16380,16562,16744,16926,17108,17290
};

// ─── Period-to-Index LUT ──────────────────────────────────
const uint8_t period_to_index[256] PROGMEM = {
  31,31,31,31,31,31,31,31,31,31,
  31,31,31,31,31,30,30,30,29,29,
  28,28,27,27,26,26,25,25,24,24,
  23,23,22,22,21,21,21,20,20,19,
  19,19,18,18,18,17,17,17,16,16,
  16,15,15,15,14,14,14,13,13,13,
  12,12,12,12,11,11,11,10,10,10,
  10, 9, 9, 9, 9, 8, 8, 8, 7, 7,
   7, 7, 6, 6, 6, 6, 5, 5, 5, 5,
   4, 4, 4, 4, 3, 3, 3, 3, 3, 2,
   2, 2, 2, 2, 1, 1, 1, 1, 1, 1,
   1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0
};

// ─── State Variables ──────────────────────────────────────
volatile uint32_t pulse_period = 0;
volatile bool     pulse_ready  = false;
volatile uint8_t  ovf_count    = 0;

uint8_t spark_count = 0;

// Serial buffer
char    serial_buf[SERIAL_BUF];
uint8_t serial_pos   = 0;
bool    serial_ready = false;

// ─── ISR: Timer1 Overflow ─────────────────────────────────
ISR(TIMER1_OVF_vect) {
  if (ovf_count < 4) ovf_count++;
}

// ─── ISR: INT0 - Pulser Capture ───────────────────────────
ISR(INT0_vect) {
  register uint16_t tcnt = TCNT1;
  register uint8_t  ovf  = ovf_count;
  if (TIFR1 & (1 << TOV1)) ovf++;
  pulse_period = ((uint32_t)ovf << 16) | tcnt;
  ovf_count = 0;
  TCNT1  = 0;
  TIFR1  = (1 << TOV1);
  pulse_ready = true;
}

// ─── UART Functions ───────────────────────────────────────
void uart_init() {
  UBRR0H = (uint8_t)(UBRR_VAL >> 8);
  UBRR0L = (uint8_t)(UBRR_VAL);
  UCSR0B = (1 << RXEN0) | (1 << TXEN0);
  UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void uart_putchar(char c) {
  while (!(UCSR0A & (1 << UDRE0)));
  UDR0 = c;
}

void uart_print(const char* s) {
  while (*s) uart_putchar(*s++);
}

void uart_println(const char* s) {
  uart_print(s);
  uart_putchar('\r');
  uart_putchar('\n');
}

void uart_print_u16(uint16_t val) {
  char buf[6]; uint8_t i = 0;
  if (val == 0) { uart_putchar('0'); return; }
  while (val > 0) { buf[i++] = '0' + (val % 10); val /= 10; }
  while (i > 0) uart_putchar(buf[--i]);
}

void uart_print_u32(uint32_t val) {
  char buf[11]; uint8_t i = 0;
  if (val == 0) { uart_putchar('0'); return; }
  while (val > 0) { buf[i++] = '0' + (uint8_t)(val % 10); val /= 10; }
  while (i > 0) uart_putchar(buf[--i]);
}

void uart_poll() {
  if (!(UCSR0A & (1 << RXC0))) return;
  char c = UDR0;
  if (c == '\n' || c == '\r') {
    if (serial_pos > 0) {
      serial_buf[serial_pos] = '\0';
      serial_ready = true;
    }
  } else if (serial_pos < SERIAL_BUF - 1) {
    serial_buf[serial_pos++] = c;
  }
}

// ─── Config Functions ─────────────────────────────────────
uint8_t compute_checksum(const CDI_Config* c) {
  uint8_t cs = 0;
  const uint8_t* p = (const uint8_t*)c;
  for (uint8_t i = 0; i < sizeof(CDI_Config) - 1; i++) cs ^= p[i];
  return cs;
}

void load_config() {
  uint8_t magic = eeprom_read_byte(&eeprom_magic);
  if (magic == EEPROM_MAGIC) {
    eeprom_read_block(&cfg, &eeprom_cfg, sizeof(CDI_Config));
    if (compute_checksum(&cfg) == cfg.checksum) return;
  }
  // Load defaults
  memcpy_P(&cfg, &DEFAULT_CONFIG, sizeof(CDI_Config));
  cfg.checksum = compute_checksum(&cfg);
}

void save_config() {
  cfg.checksum = compute_checksum(&cfg);
  eeprom_update_block(&cfg, &eeprom_cfg, sizeof(CDI_Config));
  eeprom_update_byte(&eeprom_magic, EEPROM_MAGIC);
}

void send_config() {
  // MAP
  uart_print("MAP:");
  for (uint8_t i = 0; i < MAP_SIZE; i++) {
    uart_print_u16(cfg.advance_map[i]);
    if (i < MAP_SIZE - 1) uart_putchar(',');
  }
  uart_putchar('\r'); uart_putchar('\n');
  // LIM
  uart_print("LIM:");
  uart_print_u16(cfg.rpm_limiter);
  uart_putchar('\r'); uart_putchar('\n');
  // ANG
  uart_print("ANG:");
  uart_print_u16(cfg.pulser_angle);
  uart_putchar('\r'); uart_putchar('\n');
}

// ─── Command Parser ───────────────────────────────────────
void parse_command() {
  serial_ready = false;
  serial_pos   = 0;
  char* buf    = serial_buf;

  if (strcmp(buf, "GET") == 0) {
    send_config(); return;
  }
  if (strcmp(buf, "SAVE") == 0) {
    save_config(); uart_println("OK"); return;
  }
  if (strncmp(buf, "LIM:", 4) == 0) {
    uint16_t v = (uint16_t)atoi(buf + 4);
    if (v >= 1000 && v <= 16000) { cfg.rpm_limiter = v; uart_println("OK"); }
    else uart_println("ERR");
    return;
  }
  if (strncmp(buf, "ANG:", 4) == 0) {
    uint8_t v = (uint8_t)atoi(buf + 4);
    if (v >= 50 && v <= 95) { cfg.pulser_angle = v; uart_println("OK"); }
    else uart_println("ERR");
    return;
  }
  if (strncmp(buf, "MAP:", 4) == 0) {
    char* p = buf + 4;
    uint8_t new_map[MAP_SIZE];
    uint8_t i = 0;
    while (i < MAP_SIZE && p && *p) {
      new_map[i++] = (uint8_t)atoi(p);
      p = strchr(p, ',');
      if (p) p++;
    }
    if (i == MAP_SIZE) {
      memcpy(cfg.advance_map, new_map, MAP_SIZE);
      uart_println("OK");
    } else uart_println("ERR");
    return;
  }

  uart_println("ERR");
}

// ─── Timing Functions ─────────────────────────────────────
static inline uint8_t get_rpm_index(register uint32_t period) {
  if (period > 256000UL) return 0;
  uint16_t norm = (period >= 1000) ? (uint16_t)(period / 1000) : 0;
  if (norm > 255) norm = 255;
  return pgm_read_byte(&period_to_index[norm]);
}

static inline uint16_t calc_fire_delay(register uint32_t period, register uint8_t advance_deg) {
  uint8_t angle_diff = cfg.pulser_angle - advance_deg;
  if (angle_diff >= 96) angle_diff = 95;
  uint16_t factor     = pgm_read_word(&angle_factor[angle_diff]);
  uint32_t delay_fp   = period * (uint32_t)factor;
  uint16_t result     = (uint16_t)(delay_fp >> 16);
  if (result > MAX_FIRE_TICK) return MAX_FIRE_TICK - SCR_PULSE - 1;
  return result;
}

static inline void fire_scr(register uint16_t wait_tick) {
  register uint16_t t = TCNT1;
  while ((uint16_t)(TCNT1 - t) < wait_tick);
  PORTB |= 0x02;
  t = TCNT1;
  while ((uint16_t)(TCNT1 - t) < SCR_PULSE);
  PORTB &= ~0x02;
}

// ════════════════════════════════════════════════════════════
// MAIN
// ════════════════════════════════════════════════════════════
int main() {
  PORTB  = 0x00;
  DDRB   = 0x22;   // PB1, PB5 = output
  ADCSRA = 0x00;   // ADC off

  // Timer1: 2MHz (0.5µs/tick)
  TCCR1A = 0x00; TCCR1B = 0x02;
  TCNT1  = 0;    TIMSK1 = (1 << TOIE1);

  // INT0: falling edge
  EICRA = (1 << ISC01); EIMSK = (1 << INT0);

  uart_init();
  load_config();
  sei();

  uint32_t period;
  uint16_t fire_delay;
  uint8_t  rpm_index, advance_deg;
  uint8_t  led_state = 0;

  while (1) {
    uart_poll();
    if (serial_ready) parse_command();
    if (!pulse_ready) continue;

    cli();
    period = pulse_period;
    pulse_ready = false;
    sei();

    if (period < 100 || period > 240000) continue;

    // ── RPM Report (setiap 8 spark) ──────────────────────
    spark_count++;
    if (spark_count >= 8) {
      spark_count = 0;
      uint32_t rpm = 120000000UL / period;
      uart_print("RPM:");
      uart_print_u32(rpm);
      uart_putchar('\r'); uart_putchar('\n');
      led_state ^= 0x20;
      PORTB = (PORTB & ~0x20) | led_state;
    }

    // ── RPM Limiter ──────────────────────────────────────
    if (cfg.rpm_limiter > 0) {
      uint32_t lim_period = 120000000UL / (uint32_t)cfg.rpm_limiter;
      if (period < lim_period) continue; // Over limit, skip fire
    }

    // ── Fire SCR ─────────────────────────────────────────
    rpm_index   = get_rpm_index(period);
    advance_deg = cfg.advance_map[rpm_index];
    fire_delay  = calc_fire_delay(period, advance_deg);
    fire_scr(fire_delay);
  }
  return 0;
}
