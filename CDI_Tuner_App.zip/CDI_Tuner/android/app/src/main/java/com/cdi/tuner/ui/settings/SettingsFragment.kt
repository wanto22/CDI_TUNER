package com.cdi.tuner.ui.settings

import android.os.Bundle
import android.view.*
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.cdi.tuner.databinding.FragmentSettingsBinding
import com.cdi.tuner.viewmodel.MainViewModel

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        FragmentSettingsBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAngleSeekBar()
        setupLimiterSeekBar()
        setupButtons()
        observeViewModel()
    }

    private fun setupAngleSeekBar() {
        // Range: 50-95°, offset = 50
        binding.seekAngle.max = 45
        binding.seekAngle.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val angle = progress + 50
                binding.tvAngleValue.text = "$angle°"
                if (fromUser) viewModel.updateEditAngle(angle)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun setupLimiterSeekBar() {
        // Range: 4000-16000 RPM, step 500
        // progress 0-24 → RPM = (progress * 500) + 4000
        binding.seekLimiter.max = 24
        binding.seekLimiter.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val rpm = (progress * 500) + 4000
                binding.tvLimiterValue.text = "$rpm RPM"
                if (fromUser) viewModel.updateEditLimiter(rpm)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun setupButtons() {
        binding.btnSendSettings.setOnClickListener {
            val cfg = viewModel.editConfig.value ?: return@setOnClickListener
            viewModel.sendPulserAngle(cfg.pulserAngle)
            viewModel.sendLimiter(cfg.rpmLimiter)
        }
        binding.btnRevertSettings.setOnClickListener {
            viewModel.resetEditToLast()
        }
    }

    private fun observeViewModel() {
        viewModel.editConfig.observe(viewLifecycleOwner) { cfg ->
            // Update angle seekbar
            val angleProgress = (cfg.pulserAngle - 50).coerceIn(0, 45)
            binding.seekAngle.progress = angleProgress
            binding.tvAngleValue.text = "${cfg.pulserAngle}°"

            // Update limiter seekbar
            val limProgress = ((cfg.rpmLimiter - 4000) / 500).coerceIn(0, 24)
            binding.seekLimiter.progress = limProgress
            binding.tvLimiterValue.text = "${cfg.rpmLimiter} RPM"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
