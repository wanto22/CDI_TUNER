package com.cdi.tuner.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ─── Entity ───────────────────────────────────────────────
@Entity(tableName = "presets")
data class Preset(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val advanceMapJson: String,   // JSON array 32 nilai
    val rpmLimiter: Int,
    val pulserAngle: Int,
    val createdAt: Long = System.currentTimeMillis()
)

// ─── DAO ──────────────────────────────────────────────────
@Dao
interface PresetDao {
    @Query("SELECT * FROM presets ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Preset>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(preset: Preset)

    @Delete
    suspend fun delete(preset: Preset)
}

// ─── Database ─────────────────────────────────────────────
@Database(entities = [Preset::class], version = 1)
abstract class PresetDatabase : RoomDatabase() {
    abstract fun presetDao(): PresetDao

    companion object {
        @Volatile private var INSTANCE: PresetDatabase? = null

        fun getInstance(context: android.content.Context): PresetDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    PresetDatabase::class.java,
                    "cdi_presets.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
