package com.cdi.tuner.data

/**
 * Representasi config CDI di sisi Android.
 * Mirror dari struct CDI_Config di firmware.
 */
data class CdiConfig(
    val advanceMap: IntArray = IntArray(32) { defaultAdvanceMap[it] },
    val rpmLimiter: Int = 12000,
    val pulserAngle: Int = 82
) {
    companion object {
        val defaultAdvanceMap = intArrayOf(
            0, 8, 15, 20, 24, 28, 30, 32,  // 0-3500 RPM
            34,34, 34, 34, 34, 34, 34, 34,  // 4000-7500 RPM
            34,34, 34, 34, 34, 32, 30, 27,  // 8000-11500 RPM
            23,19, 17, 15, 15, 15, 10, 10   // 12000-15500 RPM
        )

        /** Konversi index → label RPM */
        fun rpmLabelForIndex(index: Int): String {
            val rpm = index * 500
            return if (rpm == 0) "Idle" else "${rpm}"
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is CdiConfig) return false
        return advanceMap.contentEquals(other.advanceMap) &&
               rpmLimiter == other.rpmLimiter &&
               pulserAngle == other.pulserAngle
    }

    override fun hashCode(): Int {
        var result = advanceMap.contentHashCode()
        result = 31 * result + rpmLimiter
        result = 31 * result + pulserAngle
        return result
    }
}
