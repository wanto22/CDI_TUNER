package com.cdi.tuner.ui.monitor

import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.cdi.tuner.MainActivity
import com.cdi.tuner.R
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.databinding.FragmentMonitorBinding
import com.cdi.tuner.viewmodel.MainViewModel
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter

class MonitorFragment : Fragment() {

    private var _binding: FragmentMonitorBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    private val rpmHistory = ArrayDeque<Float>(60)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        FragmentMonitorBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupChart()
        observeViewModel()

        binding.btnRefresh.setOnClickListener { viewModel.requestConfig() }
    }

    private fun setupChart() {
        binding.chartRpm.apply {
            description.isEnabled = false
            setTouchEnabled(false)
            setDrawGridBackground(false)
            legend.isEnabled = false

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawLabels(false)
                setDrawGridLines(false)
            }
            axisLeft.apply {
                axisMinimum = 0f
                axisMaximum = 16000f
                granularity = 2000f
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) = "${value.toInt()}"
                }
            }
            axisRight.isEnabled = false
        }
    }

    private fun updateChart(rpm: Int) {
        if (rpmHistory.size >= 60) rpmHistory.removeFirst()
        rpmHistory.addLast(rpm.toFloat())

        val entries = rpmHistory.mapIndexed { i, v -> Entry(i.toFloat(), v) }
        val dataSet = LineDataSet(entries, "RPM").apply {
            color = requireContext().getColor(R.color.chart_rpm)
            setDrawCircles(false)
            setDrawValues(false)
            lineWidth = 2f
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }
        binding.chartRpm.data = LineData(dataSet)
        binding.chartRpm.invalidate()
    }

    private fun observeViewModel() {
        viewModel.rpm.observe(viewLifecycleOwner) { rpm ->
            // Big RPM display
            binding.tvRpm.text = rpm.toString()
            updateChart(rpm)

            // Update current advance display
            val cfg = viewModel.config.value ?: CdiConfig()
            val index = (rpm / 500).coerceIn(0, 31)
            binding.tvAdvance.text = "${cfg.advanceMap[index]}°"

            // RPM bar progress
            binding.rpmBar.progress = (rpm * 100 / 16000).coerceIn(0, 100)

            // Color RPM text based on limiter
            val limiter = cfg.rpmLimiter
            val color = when {
                rpm >= limiter          -> requireContext().getColor(R.color.rpm_over_limit)
                rpm >= limiter * 0.9f   -> requireContext().getColor(R.color.rpm_warning)
                else                    -> requireContext().getColor(R.color.rpm_normal)
            }
            binding.tvRpm.setTextColor(color)
        }

        viewModel.config.observe(viewLifecycleOwner) { cfg ->
            binding.tvLimiter.text = "Limiter: ${cfg.rpmLimiter} RPM"
            binding.tvAngle.text = "Pulser: ${cfg.pulserAngle}°"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
