package com.cdi.tuner.connection

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbManager
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.IOException
import java.util.UUID

private const val SPP_UUID = "00001101-0000-1000-8000-00805F9B34FB"
private const val READ_TIMEOUT = 1000
private const val WRITE_TIMEOUT = 2000
private const val BAUD_RATE = 9600

// ─── Connection State ─────────────────────────────────────
sealed class ConnectionState {
    object Disconnected : ConnectionState()
    data class Connecting(val type: ConnectionType) : ConnectionState()
    data class Connected(val type: ConnectionType, val name: String) : ConnectionState()
    data class Error(val message: String) : ConnectionState()
}

enum class ConnectionType { BLUETOOTH, USB }

// ─── Connection Manager ───────────────────────────────────
class ConnectionManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val state: StateFlow<ConnectionState> = _state

    private val _incomingLines = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val incomingLines: SharedFlow<String> = _incomingLines

    // Active connections
    private var btSocket: BluetoothSocket? = null
    private var usbPort: UsbSerialPort? = null
    private var readJob: Job? = null
    private val lineBuffer = StringBuilder()

    val isConnected get() = _state.value is ConnectionState.Connected

    // ─── Bluetooth ────────────────────────────────────────
    @SuppressLint("MissingPermission")
    fun connectBluetooth(device: BluetoothDevice) {
        scope.launch {
            _state.value = ConnectionState.Connecting(ConnectionType.BLUETOOTH)
            try {
                val socket = device.createInsecureRfcommSocketToServiceRecord(UUID.fromString(SPP_UUID))
                BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                socket.connect()
                btSocket = socket
                _state.value = ConnectionState.Connected(ConnectionType.BLUETOOTH, device.name ?: "HC-05")
                startReadLoop()
            } catch (e: IOException) {
                _state.value = ConnectionState.Error("BT Error: ${e.message}")
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<BluetoothDevice> {
        return BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.toList() ?: emptyList()
    }

    // ─── USB OTG ──────────────────────────────────────────
    fun connectUsb() {
        scope.launch {
            _state.value = ConnectionState.Connecting(ConnectionType.USB)
            try {
                val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)

                if (drivers.isEmpty()) {
                    _state.value = ConnectionState.Error("Tidak ada USB device ditemukan")
                    return@launch
                }

                val driver = drivers.first()
                val device = driver.device

                // Minta permission jika belum ada
                if (!usbManager.hasPermission(device)) {
                    val intent = PendingIntent.getBroadcast(
                        context, 0,
                        Intent("com.cdi.tuner.USB_PERMISSION"),
                        PendingIntent.FLAG_IMMUTABLE
                    )
                    usbManager.requestPermission(device, intent)
                    _state.value = ConnectionState.Error("Minta izin USB — coba lagi setelah menekan OK")
                    return@launch
                }

                val connection = usbManager.openDevice(device)
                    ?: run {
                        _state.value = ConnectionState.Error("Gagal buka USB device")
                        return@launch
                    }

                val port = driver.ports.first()
                port.open(connection)
                port.setParameters(BAUD_RATE, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
                usbPort = port

                val name = device.productName ?: "USB Serial (${device.vendorId}:${device.productId})"
                _state.value = ConnectionState.Connected(ConnectionType.USB, name)
                startReadLoop()
            } catch (e: Exception) {
                _state.value = ConnectionState.Error("USB Error: ${e.message}")
            }
        }
    }

    // ─── Read Loop ────────────────────────────────────────
    private fun startReadLoop() {
        readJob?.cancel()
        readJob = scope.launch {
            val buf = ByteArray(256)
            while (isActive) {
                try {
                    val n = when {
                        btSocket != null -> {
                            val stream = btSocket!!.inputStream
                            if (stream.available() > 0) stream.read(buf) else { delay(10); 0 }
                        }
                        usbPort != null -> {
                            usbPort!!.read(buf, READ_TIMEOUT)
                        }
                        else -> break
                    }
                    if (n > 0) {
                        val chunk = String(buf, 0, n, Charsets.UTF_8)
                        processChunk(chunk)
                    }
                } catch (e: Exception) {
                    if (isActive) {
                        _state.value = ConnectionState.Error("Read error: ${e.message}")
                        break
                    }
                }
            }
        }
    }

    private fun processChunk(chunk: String) {
        lineBuffer.append(chunk)
        var idx: Int
        while (lineBuffer.indexOf('\n').also { idx = it } >= 0) {
            val line = lineBuffer.substring(0, idx).trimEnd('\r')
            lineBuffer.delete(0, idx + 1)
            if (line.isNotBlank()) {
                _incomingLines.tryEmit(line)
            }
        }
    }

    // ─── Write ────────────────────────────────────────────
    fun send(data: String) {
        scope.launch {
            try {
                val bytes = data.toByteArray(Charsets.UTF_8)
                when {
                    btSocket != null -> btSocket!!.outputStream.write(bytes)
                    usbPort  != null -> usbPort!!.write(bytes, WRITE_TIMEOUT)
                }
            } catch (e: Exception) {
                _state.value = ConnectionState.Error("Write error: ${e.message}")
            }
        }
    }

    // ─── Disconnect ───────────────────────────────────────
    fun disconnect() {
        readJob?.cancel()
        try { btSocket?.close() } catch (_: Exception) {}
        try { usbPort?.close() } catch (_: Exception) {}
        btSocket = null
        usbPort  = null
        lineBuffer.clear()
        _state.value = ConnectionState.Disconnected
    }

    fun dispose() {
        disconnect()
        scope.cancel()
    }
}
