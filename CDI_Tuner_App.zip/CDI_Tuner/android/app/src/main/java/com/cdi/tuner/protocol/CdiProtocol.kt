package com.cdi.tuner.protocol

import com.cdi.tuner.data.CdiConfig

/**
 * Parser untuk protokol serial CDI Tuner.
 *
 * Format pesan dari CDI (newline terminated):
 *   RPM:5500       → RPM saat ini
 *   MAP:0,8,15,... → advance map (32 nilai)
 *   LIM:12000      → RPM limiter
 *   ANG:82         → pulser angle
 *   OK             → perintah diterima
 *   ERR            → perintah error
 */
object CdiProtocol {

    // ─── Hasil parse pesan ────────────────────────────────
    sealed class Message {
        data class Rpm(val value: Int) : Message()
        data class Config(val config: CdiConfig) : Message()
        object Ok : Message()
        object Err : Message()
        object Unknown : Message()
    }

    // State untuk parse config multi-line
    private var partialAdvanceMap: IntArray? = null
    private var partialLimiter: Int? = null
    private var partialAngle: Int? = null

    /**
     * Parse satu baris dari CDI.
     * Config (MAP/LIM/ANG) dikumpulkan dulu, baru emit Config setelah lengkap.
     */
    fun parseLine(line: String): Message? {
        val trimmed = line.trim()
        return when {
            trimmed.startsWith("RPM:") -> {
                val rpm = trimmed.removePrefix("RPM:").toIntOrNull() ?: return null
                Message.Rpm(rpm)
            }
            trimmed.startsWith("MAP:") -> {
                val values = trimmed.removePrefix("MAP:").split(",")
                    .mapNotNull { it.trim().toIntOrNull() }
                if (values.size == 32) {
                    partialAdvanceMap = values.toIntArray()
                    tryBuildConfig()
                } else null
            }
            trimmed.startsWith("LIM:") -> {
                partialLimiter = trimmed.removePrefix("LIM:").toIntOrNull()
                tryBuildConfig()
            }
            trimmed.startsWith("ANG:") -> {
                partialAngle = trimmed.removePrefix("ANG:").toIntOrNull()
                tryBuildConfig()
            }
            trimmed == "OK"  -> Message.Ok
            trimmed == "ERR" -> Message.Err
            else -> null
        }
    }

    private fun tryBuildConfig(): Message.Config? {
        val map = partialAdvanceMap ?: return null
        val lim = partialLimiter   ?: return null
        val ang = partialAngle     ?: return null
        // Semua bagian sudah diterima → reset dan return
        partialAdvanceMap = null
        partialLimiter    = null
        partialAngle      = null
        return Message.Config(CdiConfig(map, lim, ang))
    }

    fun resetPartial() {
        partialAdvanceMap = null
        partialLimiter    = null
        partialAngle      = null
    }

    // ─── Build perintah ke CDI ────────────────────────────

    fun buildGet() = "GET\r\n"

    fun buildSave() = "SAVE\r\n"

    fun buildSetLimiter(rpm: Int) = "LIM:$rpm\r\n"

    fun buildSetAngle(deg: Int) = "ANG:$deg\r\n"

    fun buildSetMap(map: IntArray): String {
        require(map.size == 32)
        return "MAP:${map.joinToString(",")}\r\n"
    }

    fun buildFullConfig(config: CdiConfig): List<String> = listOf(
        buildSetMap(config.advanceMap),
        buildSetLimiter(config.rpmLimiter),
        buildSetAngle(config.pulserAngle),
        buildSave()
    )
}
