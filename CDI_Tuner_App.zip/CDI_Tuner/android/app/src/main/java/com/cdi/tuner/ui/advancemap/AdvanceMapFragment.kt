package com.cdi.tuner.ui.advancemap

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.cdi.tuner.R
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.databinding.FragmentAdvanceMapBinding
import com.cdi.tuner.viewmodel.MainViewModel
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter

class AdvanceMapFragment : Fragment() {

    private var _binding: FragmentAdvanceMapBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    // EditText references untuk 32 baris
    private val editTexts = arrayOfNulls<EditText>(32)
    private var isUpdatingFromViewModel = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        FragmentAdvanceMapBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        buildTable()
        setupChart()
        setupButtons()
        observeViewModel()
    }

    // ─── Build table dinamis 32 baris ─────────────────────
    private fun buildTable() {
        val table = binding.tableMap
        table.removeAllViews()

        // Header
        val header = TableRow(requireContext()).apply {
            addView(makeHeaderCell("RPM"))
            addView(makeHeaderCell("Advance (°)"))
            addView(makeHeaderCell("Slider"))
        }
        table.addView(header)

        // Data rows
        for (i in 0 until 32) {
            val row = TableRow(requireContext())

            // RPM label
            val tvRpm = TextView(requireContext()).apply {
                text = if (i == 0) "Idle" else "${i * 500}"
                setPadding(16, 8, 16, 8)
                setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodyMedium)
            }

            // EditText advance value
            val et = EditText(requireContext()).apply {
                layoutParams = TableRow.LayoutParams(120, ViewGroup.LayoutParams.WRAP_CONTENT)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                gravity = android.view.Gravity.CENTER
                setPadding(8, 4, 8, 4)
                id = View.generateViewId()
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (isUpdatingFromViewModel) return
                        val v = s.toString().toIntOrNull() ?: return
                        if (v in 0..45) {
                            viewModel.updateEditAdvanceMap(i, v)
                            updateChart(viewModel.editConfig.value ?: CdiConfig())
                        }
                    }
                })
            }
            editTexts[i] = et

            // SeekBar 0-45
            val seek = SeekBar(requireContext()).apply {
                max = 45
                layoutParams = TableRow.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) {
                            et.setText(progress.toString())
                        }
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
                id = View.generateViewId()
                tag = i
            }

            // Sync et → seek
            et.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val v = s.toString().toIntOrNull() ?: return
                    if (seek.progress != v) seek.progress = v.coerceIn(0, 45)
                }
            })

            row.addView(tvRpm)
            row.addView(et)
            row.addView(seek)
            table.addView(row)
        }
    }

    private fun makeHeaderCell(text: String) = TextView(requireContext()).apply {
        this.text = text
        setPadding(16, 12, 16, 12)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setBackgroundColor(requireContext().getColor(R.color.table_header))
        setTextColor(requireContext().getColor(R.color.table_header_text))
    }

    // ─── Chart ────────────────────────────────────────────
    private fun setupChart() {
        binding.chartAdvance.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(false)

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                granularity = 1f
                labelCount = 8
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) =
                        if (value == 0f) "Idle" else "${(value * 500).toInt()}"
                }
            }
            axisLeft.apply {
                axisMinimum = 0f
                axisMaximum = 50f
                granularity = 5f
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) = "${value.toInt()}°"
                }
            }
            axisRight.isEnabled = false
        }
    }

    private fun updateChart(cfg: CdiConfig) {
        val entries = cfg.advanceMap.mapIndexed { i, v -> Entry(i.toFloat(), v.toFloat()) }
        val dataSet = LineDataSet(entries, "Advance").apply {
            color = requireContext().getColor(R.color.chart_advance)
            fillColor = requireContext().getColor(R.color.chart_advance_fill)
            setDrawFilled(true)
            setDrawCircles(true)
            circleRadius = 3f
            setCircleColor(requireContext().getColor(R.color.chart_advance))
            setDrawValues(false)
            lineWidth = 2.5f
            mode = LineDataSet.Mode.HORIZONTAL_BEZIER
        }
        binding.chartAdvance.data = LineData(dataSet)
        binding.chartAdvance.invalidate()
    }

    private fun setupButtons() {
        binding.btnSendMap.setOnClickListener { viewModel.sendFullConfig() }
        binding.btnReset.setOnClickListener { viewModel.resetEditToDefault() }
        binding.btnRevert.setOnClickListener { viewModel.resetEditToLast() }
    }

    private fun observeViewModel() {
        viewModel.editConfig.observe(viewLifecycleOwner) { cfg ->
            isUpdatingFromViewModel = true
            for (i in 0 until 32) {
                editTexts[i]?.setText(cfg.advanceMap[i].toString())
            }
            isUpdatingFromViewModel = false
            updateChart(cfg)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
