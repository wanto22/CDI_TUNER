# CDI Tuner App - Setup Guide

## 📁 Struktur Project

```
CDI_Tuner/
├── firmware/
│   └── CDI_Mio5TF_v4.ino        ← Upload ke Arduino Nano
└── android/                      ← Buka di Android Studio
    ├── settings.gradle
    ├── build.gradle
    └── app/
        ├── build.gradle
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/com/cdi/tuner/
            │   ├── MainActivity.kt
            │   ├── connection/ConnectionManager.kt
            │   ├── data/CdiConfig.kt
            │   ├── data/PresetDatabase.kt
            │   ├── protocol/CdiProtocol.kt
            │   ├── viewmodel/MainViewModel.kt
            │   └── ui/
            │       ├── monitor/MonitorFragment.kt
            │       ├── advancemap/AdvanceMapFragment.kt
            │       ├── settings/SettingsFragment.kt
            │       └── presets/PresetsFragment.kt
            └── res/ ...
```

---

## 🔧 Upload Firmware

1. Buka `firmware/CDI_Mio5TF_v4.ino` di Arduino IDE
2. Pilih board: **Arduino Nano (ATmega328P)**
3. Compiler: **avr-gcc -O2**
4. Upload

**Perubahan dari v3.1:**
- Tambah komunikasi serial 9600 baud
- Config (advance map, limiter, angle) tersimpan di EEPROM
- RPM dikirim ke HP setiap 8 spark
- RPM limiter aktif (tidak fire SCR jika over limit)

---

## 📱 Build Android App

### Prasyarat
- Android Studio Hedgehog (2023.1.1) atau lebih baru
- JDK 17
- Android SDK 34

### Langkah
1. Buka Android Studio → **Open** → pilih folder `android/`
2. Tunggu Gradle sync selesai (butuh internet untuk download library)
3. Build & Run ke HP Android (minimal Android 8.0)

### Library yang digunakan
- `usb-serial-for-android` (mik3y) — koneksi USB OTG
- `MPAndroidChart` (PhilJay) — grafik advance map & RPM
- `Room` — simpan preset ke database lokal
- `Navigation Component` — navigasi antar fragment

---

## 🔌 Wiring

### Bluetooth (HC-05)
```
HC-05 VCC  → 5V Arduino
HC-05 GND  → GND Arduino
HC-05 TX   → D0 (RX) Arduino
HC-05 RX   → D1 (TX) Arduino  [gunakan voltage divider 5V→3.3V]
```

### USB OTG
```
USB Mini-B Arduino Nano ← kabel OTG → HP Android
```

⚠️ **Jangan sambungkan HC-05 dan USB serial bersamaan saat upload sketch!**
Cabut dulu kabel HC-05 dari pin TX/RX sebelum upload.

---

## 📱 Cara Pakai App

### Hubungkan
1. Buka app → tap **Hubungkan**
2. Pilih **Bluetooth (HC-05)** atau **USB OTG**
3. Untuk Bluetooth: pastikan HC-05 sudah di-pair dulu di Settings HP

### Monitor
- Tab pertama menampilkan RPM real-time dan advance yang sedang aktif
- Grafik histori RPM 60 detik terakhir

### Edit Advance Map
- Tab **Advance Map**: edit 32 nilai advance (RPM idle s/d 15500)
- Grafik langsung update saat editing
- Tekan **📤 Kirim ke CDI** untuk apply + simpan ke EEPROM

### Settings
- **Sudut Pulser**: default 82° untuk Mio (range 50°-95°)
- **RPM Limiter**: batas RPM, default 12000 (range 4000-16000)

### Preset
- Simpan konfigurasi yang sudah di-tune dengan nama
- Load kapanpun untuk restore tuning favorit

---

## 🔬 Protokol Serial (untuk debug)

Bisa ditest via Serial Monitor Arduino IDE (9600 baud):

```
GET         → minta semua config
MAP:0,8,15,20,24,28,30,32,34,34,34,34,34,34,34,34,34,34,34,34,34,32,30,27,23,19,17,15,15,15,10,10
LIM:11000   → set limiter ke 11000 RPM
ANG:84      → set pulser angle ke 84°
SAVE        → simpan ke EEPROM
```

---

## ⚙️ Kustomisasi Advance Map

Setiap index mewakili band RPM 500:

| Index | RPM       | Default Advance |
|-------|-----------|-----------------|
| 0     | Idle/Stop | 0°              |
| 1     | 500 RPM   | 8°              |
| 2     | 1000 RPM  | 15°             |
| 7     | 3500 RPM  | 32°             |
| 8-17  | 4000-7500 | 34° (max)       |
| 24    | 12000 RPM | 23°             |
| 31    | 15500 RPM | 10° (pull back) |

---

*CDI Tuner v4.0 — Compatible: Arduino Nano ATmega328P + HC-05 + USB OTG*
