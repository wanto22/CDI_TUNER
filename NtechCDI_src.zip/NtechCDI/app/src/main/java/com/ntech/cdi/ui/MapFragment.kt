package com.ntech.cdi.ui

import android.graphics.Color
import android.os.Bundle
import android.text.*
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.ntech.cdi.CdiConfig
import com.ntech.cdi.MainActivity
import com.ntech.cdi.R

class MapFragment : Fragment() {

    private val etMap1 = arrayOfNulls<EditText>(32)
    private val etMap2 = arrayOfNulls<EditText>(32)
    private val etMap3 = arrayOfNulls<EditText>(32)
    private lateinit var tabMap1: TextView
    private lateinit var tabMap2: TextView
    private lateinit var tabMap3: TextView
    private lateinit var tableMap1: TableLayout
    private lateinit var tableMap2: TableLayout
    private lateinit var tableMap3: TableLayout
    private var updating = false

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_map, c, false)

    override fun onViewCreated(view: View, s: Bundle?) {
        tabMap1   = view.findViewById(R.id.tabMap1)
        tabMap2   = view.findViewById(R.id.tabMap2)
        tabMap3   = view.findViewById(R.id.tabMap3)
        tableMap1 = view.findViewById(R.id.tableMap1)
        tableMap2 = view.findViewById(R.id.tableMap2)
        tableMap3 = view.findViewById(R.id.tableMap3)

        val cfg = MainActivity.config
        buildTable(tableMap1, etMap1, cfg.map1, 1)
        buildTable(tableMap2, etMap2, cfg.map2, 2)
        buildTable(tableMap3, etMap3, cfg.map3, 3)

        tabMap1.setOnClickListener { showMap(1) }
        tabMap2.setOnClickListener { showMap(2) }
        tabMap3.setOnClickListener { showMap(3) }

        view.findViewById<TextView>(R.id.btnSendM1).setOnClickListener { sendMap(1) }
        view.findViewById<TextView>(R.id.btnSendM2).setOnClickListener { sendMap(2) }
        view.findViewById<TextView>(R.id.btnSendM3).setOnClickListener { sendMap(3) }
        view.findViewById<TextView>(R.id.btnSendAll).setOnClickListener {
            sendMap(1); sendMap(2); sendMap(3)
            Toast.makeText(context, "Semua map terkirim", Toast.LENGTH_SHORT).show()
        }

        showMap(cfg.activeMap)

        MainActivity.onDataReceived = { _ ->
            activity?.runOnUiThread { refreshTables() }
        }
    }

    private fun buildTable(table: TableLayout, ets: Array<EditText?>, arr: IntArray, mapNum: Int) {
        table.removeAllViews()
        // Header
        val hRow = TableRow(requireContext())
        hRow.addView(makeHdr("RPM"))
        hRow.addView(makeHdr("Advance°"))
        table.addView(hRow)

        for (i in 0 until 32) {
            val row = TableRow(requireContext())
            // RPM label
            val tvRpm = TextView(requireContext()).apply {
                text = CdiConfig.rpmLabel(i)
                setPadding(16, 10, 16, 10)
                textSize = 13f
                setTextColor(when {
                    i <= 6  -> Color.parseColor("#4CAF50")
                    i <= 16 -> Color.parseColor("#FF9800")
                    else    -> Color.parseColor("#FF5252")
                })
            }
            // EditText nilai advance
            val et = EditText(requireContext()).apply {
                layoutParams = TableRow.LayoutParams(200, ViewGroup.LayoutParams.WRAP_CONTENT)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                gravity = android.view.Gravity.CENTER
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setText(arr[i].toString())
                setTextColor(Color.WHITE)
                setBackgroundResource(android.R.color.transparent)
                setPadding(8, 6, 8, 6)
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (updating) return
                        val v = s.toString().toIntOrNull() ?: return
                        if (v in 0..60) arr[i] = v
                    }
                })
            }
            ets[i] = et
            row.addView(tvRpm)
            row.addView(et)
            // Alternating row background
            if (i % 2 == 0) row.setBackgroundColor(Color.parseColor("#1A1A1A"))
            else row.setBackgroundColor(Color.parseColor("#222222"))
            table.addView(row)
        }
    }

    private fun makeHdr(text: String) = TextView(requireContext()).apply {
        this.text = text
        setPadding(16, 10, 16, 10)
        textSize = 12f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(Color.parseColor("#FF6B00"))
        setBackgroundColor(Color.parseColor("#1A1A2E"))
    }

    private fun refreshTables() {
        val cfg = MainActivity.config
        updating = true
        for (i in 0 until 32) {
            etMap1[i]?.setText(cfg.map1[i].toString())
            etMap2[i]?.setText(cfg.map2[i].toString())
            etMap3[i]?.setText(cfg.map3[i].toString())
        }
        updating = false
    }

    private fun showMap(m: Int) {
        tableMap1.visibility = if (m == 1) View.VISIBLE else View.GONE
        tableMap2.visibility = if (m == 2) View.VISIBLE else View.GONE
        tableMap3.visibility = if (m == 3) View.VISIBLE else View.GONE
        val orange = Color.parseColor("#FF6B00")
        val gray   = Color.parseColor("#888888")
        tabMap1.setTextColor(if (m == 1) orange else gray)
        tabMap2.setTextColor(if (m == 2) orange else gray)
        tabMap3.setTextColor(if (m == 3) orange else gray)
    }

    private fun sendMap(m: Int) {
        val cfg = MainActivity.config
        val arr = when (m) { 2 -> cfg.map2; 3 -> cfg.map3; else -> cfg.map1 }
        val prefix = when (m) { 2 -> "M2"; 3 -> "M3"; else -> "M1" }
        val cmd = cfg.buildMapCmd(prefix, arr)
        (activity as? MainActivity)?.sendCmd(cmd)
        // Set active map
        (activity as? MainActivity)?.sendCmd("ACT:$m\r\n")
        Toast.makeText(context, "Map $m terkirim & tersimpan", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        MainActivity.onDataReceived = null
    }
}
