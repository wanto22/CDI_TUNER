package com.ntech.cdi

class CdiConfig {
    val map1 = IntArray(32) { defaultMap1[it] }
    val map2 = IntArray(32) { defaultMap2[it] }
    val map3 = IntArray(32) { defaultMap3[it] }
    var rpmLimiter  = 12000
    var pulserAngle = 63
    var scrPulse    = 1000
    var rumbleRpm   = 0
    var rumbleSkip  = 3
    var activeMap   = 1
    var edge        = 0   // 0=falling, 1=rising
    var lastRpm     = 0

    companion object {
        val defaultMap1 = intArrayOf(
             0, 8,15,20,24,28,30,32,
            34,34,34,34,34,34,34,34,
            34,34,34,34,34,32,30,27,
            23,19,17,15,15,15,10,10
        )
        val defaultMap2 = intArrayOf(
             0, 6,12,18,22,26,28,30,
            32,32,32,32,32,32,32,32,
            32,32,32,30,28,26,24,22,
            20,17,15,12,12,12, 8, 8
        )
        val defaultMap3 = intArrayOf(
             0, 5,12,18,24,30,34,36,
            38,40,40,40,40,40,38,36,
            34,32,30,28,26,24,22,20,
            18,15,12,10,10,10, 8, 8
        )

        fun rpmLabel(i: Int) = if (i == 0) "Idle" else "${i * 500}"
        fun tickToUs(tick: Int) = tick / 2
        fun usToTick(us: Int)   = us * 2
    }

    fun activeMapArray() = when (activeMap) { 2 -> map2; 3 -> map3; else -> map1 }

    fun parseLine(line: String) {
        when {
            line.startsWith("RPM:") -> lastRpm = line.removePrefix("RPM:").toIntOrNull() ?: lastRpm
            line.startsWith("ACT:") -> activeMap = line.removePrefix("ACT:").toIntOrNull() ?: activeMap
            line.startsWith("LIM:") -> rpmLimiter = line.removePrefix("LIM:").toIntOrNull() ?: rpmLimiter
            line.startsWith("ANG:") -> pulserAngle = line.removePrefix("ANG:").toIntOrNull() ?: pulserAngle
            line.startsWith("SCR:") -> scrPulse = line.removePrefix("SCR:").toIntOrNull() ?: scrPulse
            line.startsWith("RBL:") -> rumbleRpm = line.removePrefix("RBL:").toIntOrNull() ?: rumbleRpm
            line.startsWith("RSK:") -> rumbleSkip = line.removePrefix("RSK:").toIntOrNull() ?: rumbleSkip
            line.startsWith("EDG:") -> edge = line.removePrefix("EDG:").toIntOrNull() ?: edge
            line.startsWith("M1:") -> parseMapLine(line.removePrefix("M1:"), map1)
            line.startsWith("M2:") -> parseMapLine(line.removePrefix("M2:"), map2)
            line.startsWith("M3:") -> parseMapLine(line.removePrefix("M3:"), map3)
        }
    }

    private fun parseMapLine(csv: String, arr: IntArray) {
        val parts = csv.split(",")
        parts.forEachIndexed { i, v ->
            if (i < 32) arr[i] = v.trim().toIntOrNull() ?: arr[i]
        }
    }

    fun buildMapCmd(prefix: String, arr: IntArray) = "$prefix:${arr.joinToString(",")}\r\n"
}
