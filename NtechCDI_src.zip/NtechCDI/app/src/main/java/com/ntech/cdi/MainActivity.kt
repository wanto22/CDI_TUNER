package com.ntech.cdi

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.*
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.ntech.cdi.ui.MapFragment
import com.ntech.cdi.ui.MonitorFragment
import com.ntech.cdi.ui.SettingsFragment
import java.io.*
import java.util.*

class MainActivity : AppCompatActivity() {

    companion object {
        var socket: BluetoothSocket? = null
        var outStream: OutputStream? = null
        var inStream: InputStream? = null
        var isConnected = false
        var onDataReceived: ((String) -> Unit)? = null
        val config = CdiConfig()
    }

    private lateinit var tvStatus: TextView
    private lateinit var btnConnect: TextView
    private lateinit var tvConnectionInfo: TextView
    private lateinit var navMonitor: TextView
    private lateinit var navMap: TextView
    private lateinit var navSettings: TextView
    private var currentTab = 0
    private var readThread: Thread? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            getSharedPreferences("ntech", MODE_PRIVATE).edit()
                .putString("bg_uri", it.toString()).apply()
            applyBackground(it.toString())
            Toast.makeText(this, "Gambar background diubah", Toast.LENGTH_SHORT).show()
        }
    }

    private val requestBt = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
        if (perms.values.all { it }) showBtDialog()
        else Toast.makeText(this, "Izin Bluetooth diperlukan", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnConnect = findViewById(R.id.btnConnect)
        tvConnectionInfo = findViewById(R.id.tvConnectionInfo)
        navMonitor = findViewById(R.id.navMonitor)
        navMap = findViewById(R.id.navMap)
        navSettings = findViewById(R.id.navSettings)

        // Restore background
        val bgUri = getSharedPreferences("ntech", MODE_PRIVATE).getString("bg_uri", null)
        bgUri?.let { applyBackground(it) }

        btnConnect.setOnClickListener {
            if (isConnected) disconnect()
            else checkAndConnect()
        }

        navMonitor.setOnClickListener { showTab(0) }
        navMap.setOnClickListener { showTab(1) }
        navSettings.setOnClickListener { showTab(2) }

        showTab(0)
        updateConnectionUI()
    }

    private fun applyBackground(uriStr: String) {
        try {
            val uri = Uri.parse(uriStr)
            val bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(uri))
            findViewById<android.widget.FrameLayout>(R.id.rootLayout)
                .background = android.graphics.drawable.BitmapDrawable(resources, bmp)
        } catch (e: Exception) { }
    }

    fun changeBackground() = pickImage.launch("image/*")

    private fun showTab(tab: Int) {
        currentTab = tab
        val frag: Fragment = when (tab) {
            0 -> MonitorFragment()
            1 -> MapFragment()
            else -> SettingsFragment()
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragContainer, frag).commit()

        val orange = 0xFFFF6B00.toInt()
        val white  = 0xFFFFFFFF.toInt()
        navMonitor.setTextColor(if (tab == 0) orange else white)
        navMap.setTextColor(if (tab == 1) orange else white)
        navSettings.setTextColor(if (tab == 2) orange else white)
    }

    private fun checkAndConnect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestBt.launch(arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            ))
        } else showBtDialog()
    }

    @SuppressLint("MissingPermission")
    private fun showBtDialog() {
        val ba = BluetoothAdapter.getDefaultAdapter()
        if (ba == null || !ba.isEnabled) {
            Toast.makeText(this, "Aktifkan Bluetooth terlebih dahulu", Toast.LENGTH_SHORT).show()
            return
        }
        val paired = ba.bondedDevices.toList()
        if (paired.isEmpty()) {
            Toast.makeText(this, "Tidak ada perangkat Bluetooth terpasang", Toast.LENGTH_LONG).show()
            return
        }
        val names = paired.map { "${it.name}  |  ${it.address}" }.toTypedArray()
        AlertDialog.Builder(this, R.style.NtechDialog)
            .setTitle("Pilih Perangkat Bluetooth")
            .setItems(names) { _, idx -> connectBt(paired[idx]) }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun connectBt(device: BluetoothDevice) {
        tvStatus.text = "Menghubungkan..."
        tvStatus.setTextColor(0xFFFF9800.toInt())
        Thread {
            try {
                val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                val s = device.createRfcommSocketToServiceRecord(uuid)
                s.connect()
                socket = s
                outStream = s.outputStream
                inStream  = s.inputStream
                isConnected = true
                runOnUiThread { updateConnectionUI(device.name) }
                startReading()
                sendCmd("GET\r\n")
            } catch (e: Exception) {
                isConnected = false
                runOnUiThread {
                    tvStatus.text = "Gagal terhubung"
                    tvStatus.setTextColor(0xFFFF3333.toInt())
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun startReading() {
        readThread = Thread {
            val buf = ByteArray(256)
            val sb = StringBuilder()
            while (isConnected) {
                try {
                    val n = inStream?.read(buf) ?: break
                    if (n > 0) {
                        val s = String(buf, 0, n)
                        sb.append(s)
                        var idx: Int
                        while (sb.indexOf("\n").also { idx = it } >= 0) {
                            val line = sb.substring(0, idx).trim()
                            sb.delete(0, idx + 1)
                            if (line.isNotEmpty()) {
                                config.parseLine(line)
                                runOnUiThread { onDataReceived?.invoke(line) }
                            }
                        }
                    }
                } catch (e: Exception) { break }
            }
        }
        readThread?.start()
    }

    fun sendCmd(cmd: String) {
        Thread { outStream?.write(cmd.toByteArray()) }.start()
    }

    private fun disconnect() {
        isConnected = false
        try { socket?.close() } catch (e: Exception) { }
        socket = null; outStream = null; inStream = null
        updateConnectionUI()
    }

    private fun updateConnectionUI(name: String = "") {
        if (isConnected) {
            tvStatus.text = "● Terhubung"
            tvStatus.setTextColor(0xFF00E676.toInt())
            tvConnectionInfo.text = name
            btnConnect.text = "Putuskan"
            btnConnect.setBackgroundColor(0xFFCC3333.toInt())
        } else {
            tvStatus.text = "● Terputus"
            tvStatus.setTextColor(0xFFFF5252.toInt())
            tvConnectionInfo.text = ""
            btnConnect.text = "Hubungkan"
            btnConnect.setBackgroundColor(0xFFFF6B00.toInt())
        }
    }
}
