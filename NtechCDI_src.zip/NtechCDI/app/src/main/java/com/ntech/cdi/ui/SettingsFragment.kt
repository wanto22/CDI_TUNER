package com.ntech.cdi.ui

import android.os.Bundle
import android.text.*
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.ntech.cdi.CdiConfig
import com.ntech.cdi.MainActivity
import com.ntech.cdi.R

class SettingsFragment : Fragment() {

    private lateinit var etLimiter: EditText
    private lateinit var etAngle: EditText
    private lateinit var etScr: EditText
    private lateinit var rgEdge: RadioGroup
    private lateinit var rbFalling: RadioButton
    private lateinit var rbRising: RadioButton
    private lateinit var spinnerRumbleRpm: Spinner
    private lateinit var spinnerRumbleSkip: Spinner
    private var updating = false

    // Pilihan Rumble RPM dalam tabel
    private val rumbleRpmOptions = listOf(
        "OFF (0)",
        "250 RPM",  "500 RPM",  "750 RPM",
        "1000 RPM", "1200 RPM", "1500 RPM",
        "1800 RPM", "2000 RPM", "2500 RPM", "3000 RPM"
    )
    private val rumbleRpmValues = listOf(0, 250, 500, 750, 1000, 1200, 1500, 1800, 2000, 2500, 3000)

    // Pilihan Rumble Skip
    private val rumbleSkipOptions = listOf(
        "2 spark (Kasar)", "3 spark", "4 spark",
        "5 spark", "6 spark", "7 spark", "8 spark (Halus)"
    )
    private val rumbleSkipValues = listOf(2, 3, 4, 5, 6, 7, 8)

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_settings, c, false)

    override fun onViewCreated(view: View, s: Bundle?) {
        etLimiter        = view.findViewById(R.id.etLimiter)
        etAngle          = view.findViewById(R.id.etAngle)
        etScr            = view.findViewById(R.id.etScr)
        rgEdge           = view.findViewById(R.id.rgEdge)
        rbFalling        = view.findViewById(R.id.rbFalling)
        rbRising         = view.findViewById(R.id.rbRising)
        spinnerRumbleRpm = view.findViewById(R.id.spinnerRumbleRpm)
        spinnerRumbleSkip= view.findViewById(R.id.spinnerRumbleSkip)

        // Setup spinners
        val rpmAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, rumbleRpmOptions)
        rpmAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerRumbleRpm.adapter = rpmAdapter

        val skipAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, rumbleSkipOptions)
        skipAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerRumbleSkip.adapter = skipAdapter

        loadFromConfig()

        // Buttons
        view.findViewById<TextView>(R.id.btnSendLim).setOnClickListener {
            val v = etLimiter.text.toString().toIntOrNull() ?: return@setOnClickListener
            if (v in 1000..16000) send("LIM:$v\r\n", "Limiter: $v RPM")
            else toast("Limiter harus 1000-16000")
        }
        view.findViewById<TextView>(R.id.btnSendAngle).setOnClickListener {
            val v = etAngle.text.toString().toIntOrNull() ?: return@setOnClickListener
            if (v in 30..120) send("ANG:$v\r\n", "Pulser Angle: $v°")
            else toast("Angle harus 30-120")
        }
        view.findViewById<TextView>(R.id.btnSendScr).setOnClickListener {
            val us = etScr.text.toString().toIntOrNull() ?: return@setOnClickListener
            val tick = CdiConfig.usToTick(us)
            if (tick in 200..4000) send("SCR:$tick\r\n", "SCR: ${us}µs")
            else toast("SCR harus 100-2000µs")
        }
        view.findViewById<TextView>(R.id.btnSendEdge).setOnClickListener {
            val edge = if (rbFalling.isChecked) 0 else 1
            send("EDG:$edge\r\n", "Edge: ${if(edge==0)"Falling" else "Rising"}")
        }
        view.findViewById<TextView>(R.id.btnSendRumble).setOnClickListener {
            val rpmIdx  = spinnerRumbleRpm.selectedItemPosition
            val skipIdx = spinnerRumbleSkip.selectedItemPosition
            val rpm  = rumbleRpmValues[rpmIdx]
            val skip = rumbleSkipValues[skipIdx]
            (activity as? MainActivity)?.sendCmd("RBL:$rpm\r\n")
            (activity as? MainActivity)?.sendCmd("RSK:$skip\r\n")
            toast("Rumble: ${if(rpm==0)"OFF" else "${rpm}RPM"}, Skip: $skip")
        }
        view.findViewById<TextView>(R.id.btnGetConfig).setOnClickListener {
            (activity as? MainActivity)?.sendCmd("GET\r\n")
            toast("Meminta config dari CDI...")
        }
        view.findViewById<TextView>(R.id.btnChangeBg).setOnClickListener {
            (activity as? MainActivity)?.changeBackground()
        }

        MainActivity.onDataReceived = { _ -> activity?.runOnUiThread { loadFromConfig() } }
    }

    private fun loadFromConfig() {
        updating = true
        val cfg = MainActivity.config
        etLimiter.setText(cfg.rpmLimiter.toString())
        etAngle.setText(cfg.pulserAngle.toString())
        etScr.setText(CdiConfig.tickToUs(cfg.scrPulse).toString())

        if (cfg.edge == 0) rbFalling.isChecked = true else rbRising.isChecked = true

        val rpmIdx = rumbleRpmValues.indexOf(cfg.rumbleRpm).takeIf { it >= 0 } ?: 0
        spinnerRumbleRpm.setSelection(rpmIdx)

        val skipIdx = rumbleSkipValues.indexOf(cfg.rumbleSkip).takeIf { it >= 0 } ?: 1
        spinnerRumbleSkip.setSelection(skipIdx)
        updating = false
    }

    private fun send(cmd: String, msg: String) {
        (activity as? MainActivity)?.sendCmd(cmd)
        toast("$msg — tersimpan")
    }

    private fun toast(msg: String) =
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() {
        super.onDestroyView()
        MainActivity.onDataReceived = null
    }
}
