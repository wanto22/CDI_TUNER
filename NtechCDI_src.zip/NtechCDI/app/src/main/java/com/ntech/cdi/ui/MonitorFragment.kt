package com.ntech.cdi.ui

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.ntech.cdi.MainActivity
import com.ntech.cdi.R

class MonitorFragment : Fragment() {

    private lateinit var tvRpm: TextView
    private lateinit var tvRpmBar: ProgressBar
    private lateinit var tvActiveMap: TextView
    private lateinit var tvLimiter: TextView
    private lateinit var tvAngle: TextView
    private lateinit var tvEdge: TextView
    private lateinit var tvScr: TextView
    private lateinit var tvMaxRpm: TextView
    private lateinit var btnResetMax: TextView
    private var maxRpm = 0

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        inflater.inflate(R.layout.fragment_monitor, c, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        tvRpm       = view.findViewById(R.id.tvRpm)
        tvRpmBar    = view.findViewById(R.id.rpmBar)
        tvActiveMap = view.findViewById(R.id.tvActiveMap)
        tvLimiter   = view.findViewById(R.id.tvLimiter)
        tvAngle     = view.findViewById(R.id.tvAngle)
        tvEdge      = view.findViewById(R.id.tvEdge)
        tvScr       = view.findViewById(R.id.tvScr)
        tvMaxRpm    = view.findViewById(R.id.tvMaxRpm)
        btnResetMax = view.findViewById(R.id.btnResetMax)

        btnResetMax.setOnClickListener {
            maxRpm = 0
            tvMaxRpm.text = "Max: 0 RPM"
        }

        view.findViewById<TextView>(R.id.btnRefresh).setOnClickListener {
            (activity as? MainActivity)?.sendCmd("GET\r\n")
        }

        updateUI()
        MainActivity.onDataReceived = { _ -> activity?.runOnUiThread { updateUI() } }
    }

    private fun updateUI() {
        val cfg = MainActivity.config
        val rpm = cfg.lastRpm
        if (rpm > maxRpm) { maxRpm = rpm; tvMaxRpm.text = "Max: $maxRpm RPM" }

        tvRpm.text = rpm.toString()
        val pct = (rpm * 100 / 16000).coerceIn(0, 100)
        tvRpmBar.progress = pct

        val color = when {
            rpm >= cfg.rpmLimiter -> 0xFFFF3333.toInt()
            rpm >= cfg.rpmLimiter * 0.85 -> 0xFFFF9800.toInt()
            else -> 0xFF00E676.toInt()
        }
        tvRpm.setTextColor(color)

        tvActiveMap.text = "Map ${cfg.activeMap}: ${when(cfg.activeMap){2->"Touring";3->"Racing";else->"Harian"}}"
        tvLimiter.text = "Limiter: ${cfg.rpmLimiter} RPM"
        tvAngle.text = "Pulser: ${cfg.pulserAngle}°"
        tvEdge.text = "Edge: ${if(cfg.edge==0) "Falling" else "Rising"}"
        tvScr.text = "SCR: ${CdiConfig.tickToUs(cfg.scrPulse)}µs"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        MainActivity.onDataReceived = null
    }
}
