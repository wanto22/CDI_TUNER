package com.cdi.tuner.protocol

import com.cdi.tuner.data.CdiConfig

object CdiProtocol {

    sealed class Message {
        data class Rpm(val value: Int) : Message()
        data class Config(val config: CdiConfig) : Message()
        object Ok : Message()
        object Err : Message()
        object Unknown : Message()
    }

    // State untuk parse config multi-line
    private var pMap: IntArray? = null
    private var pLim: Int? = null
    private var pAng: Int? = null
    private var pScr: Int? = null
    private var pRbl: Int? = null
    private var pRsk: Int? = null

    fun parseLine(line: String): Message? {
        val t = line.trim()
        return when {
            t.startsWith("RPM:") -> {
                val rpm = t.removePrefix("RPM:").toIntOrNull() ?: return null
                Message.Rpm(rpm)
            }
            t.startsWith("MAP:") -> {
                val values = t.removePrefix("MAP:").split(",")
                    .mapNotNull { it.trim().toIntOrNull() }
                if (values.size == 32) { pMap = values.toIntArray(); tryBuild() } else null
            }
            t.startsWith("LIM:") -> { pLim = t.removePrefix("LIM:").toIntOrNull(); tryBuild() }
            t.startsWith("ANG:") -> { pAng = t.removePrefix("ANG:").toIntOrNull(); tryBuild() }
            t.startsWith("SCR:") -> { pScr = t.removePrefix("SCR:").toIntOrNull(); tryBuild() }
            t.startsWith("RBL:") -> { pRbl = t.removePrefix("RBL:").toIntOrNull(); tryBuild() }
            t.startsWith("RSK:") -> { pRsk = t.removePrefix("RSK:").toIntOrNull(); tryBuild() }
            t == "OK"  -> Message.Ok
            t == "ERR" -> Message.Err
            else -> null
        }
    }

    private fun tryBuild(): Message.Config? {
        val map = pMap ?: return null
        val lim = pLim ?: return null
        val ang = pAng ?: return null
        val scr = pScr ?: return null
        val rbl = pRbl ?: return null
        val rsk = pRsk ?: return null
        pMap = null; pLim = null; pAng = null
        pScr = null; pRbl = null; pRsk = null
        return Message.Config(CdiConfig(map, lim, ang, scr, rbl, rsk))
    }

    fun resetPartial() {
        pMap = null; pLim = null; pAng = null
        pScr = null; pRbl = null; pRsk = null
    }

    fun buildGet()  = "GET\r\n"
    fun buildSave() = "SAVE\r\n"
    fun buildSetLimiter(rpm: Int)  = "LIM:$rpm\r\n"
    fun buildSetAngle(deg: Int)    = "ANG:$deg\r\n"
    fun buildSetScrPulse(tick: Int) = "SCR:$tick\r\n"
    fun buildSetRumbleRpm(rpm: Int) = "RBL:$rpm\r\n"
    fun buildSetRumbleSkip(n: Int)  = "RSK:$n\r\n"

    fun buildSetMap(map: IntArray): String {
        require(map.size == 32)
        return "MAP:${map.joinToString(",")}\r\n"
    }

    fun buildFullConfig(config: CdiConfig): List<String> = listOf(
        buildSetMap(config.advanceMap),
        buildSetLimiter(config.rpmLimiter),
        buildSetAngle(config.pulserAngle),
        buildSetScrPulse(config.scrPulse),
        buildSetRumbleRpm(config.rumbleRpm),
        buildSetRumbleSkip(config.rumbleSkip),
        buildSave()
    )
}
