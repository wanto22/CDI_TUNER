package com.cdi.tuner.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "presets")
data class Preset(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val advanceMapJson: String,
    val rpmLimiter: Int,
    val pulserAngle: Int,
    val scrPulse: Int = 1000,
    val rumbleRpm: Int = 0,
    val rumbleSkip: Int = 3,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface PresetDao {
    @Query("SELECT * FROM presets ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Preset>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(preset: Preset)

    @Delete
    suspend fun delete(preset: Preset)
}

@Database(entities = [Preset::class], version = 2)
abstract class PresetDatabase : RoomDatabase() {
    abstract fun presetDao(): PresetDao

    companion object {
        @Volatile private var INSTANCE: PresetDatabase? = null

        fun getInstance(context: android.content.Context): PresetDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    PresetDatabase::class.java,
                    "cdi_presets.db"
                )
                .fallbackToDestructiveMigration()
                .build().also { INSTANCE = it }
            }
        }
    }
}
