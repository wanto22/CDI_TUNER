package com.cdi.tuner.ui.settings

import android.os.Bundle
import android.view.*
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.databinding.FragmentSettingsBinding
import com.cdi.tuner.viewmodel.MainViewModel

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private var isUpdating = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        FragmentSettingsBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAngleSeekBar()
        setupLimiterSeekBar()
        setupScrPulseSeekBar()
        setupRumbleSeekBar()
        setupButtons()
        observeViewModel()
    }

    // ── Pulser Angle (50-95°) ────────────────────────────
    private fun setupAngleSeekBar() {
        binding.seekAngle.max = 45
        binding.seekAngle.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val angle = progress + 50
                binding.tvAngleValue.text = "$angle°"
                if (fromUser && !isUpdating) viewModel.updateEditAngle(angle)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    // ── RPM Limiter (4000-16000, step 500) ───────────────
    private fun setupLimiterSeekBar() {
        binding.seekLimiter.max = 24
        binding.seekLimiter.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val rpm = (progress * 500) + 4000
                binding.tvLimiterValue.text = "$rpm RPM"
                if (fromUser && !isUpdating) viewModel.updateEditLimiter(rpm)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    // ── SCR Pulse Width (100-2000µs, step 50µs) ─────────
    // tick = us * 2, range: 200-4000 tick
    // SeekBar: 0-38 → us = (progress * 50) + 100
    private fun setupScrPulseSeekBar() {
        binding.seekScr.max = 38
        binding.seekScr.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val us = (progress * 50) + 100
                val tick = CdiConfig.usToTick(us)
                binding.tvScrValue.text = "${us}µs (${tick} tick)"
                if (fromUser && !isUpdating) viewModel.updateEditScrPulse(tick)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    // ── Rumble Idle RPM (0=off, 500-3000) ────────────────
    // SeekBar: 0-26 → 0=off, 1-26 = 500-3000 RPM (step 100)
    private fun setupRumbleSeekBar() {
        binding.seekRumble.max = 26
        binding.seekRumble.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val rpm = if (progress == 0) 0 else (progress * 100) + 400
                binding.tvRumbleValue.text = if (rpm == 0) "OFF" else "$rpm RPM"
                if (fromUser && !isUpdating) viewModel.updateEditRumbleRpm(rpm)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Rumble Skip (2-8)
        binding.seekRumbleSkip.max = 6  // 0-6 → 2-8
        binding.seekRumbleSkip.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val skip = progress + 2
                binding.tvRumbleSkipValue.text = "Setiap $skip spark"
                if (fromUser && !isUpdating) viewModel.updateEditRumbleSkip(skip)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun setupButtons() {
        binding.btnSendSettings.setOnClickListener {
            val cfg = viewModel.editConfig.value ?: return@setOnClickListener
            viewModel.sendPulserAngle(cfg.pulserAngle)
            viewModel.sendLimiter(cfg.rpmLimiter)
            viewModel.sendScrPulse(cfg.scrPulse)
            viewModel.sendRumble(cfg.rumbleRpm, cfg.rumbleSkip)
        }
        binding.btnRevertSettings.setOnClickListener {
            viewModel.resetEditToLast()
        }
    }

    private fun observeViewModel() {
        viewModel.editConfig.observe(viewLifecycleOwner) { cfg ->
            isUpdating = true

            // Angle
            binding.seekAngle.progress = (cfg.pulserAngle - 50).coerceIn(0, 45)
            binding.tvAngleValue.text = "${cfg.pulserAngle}°"

            // Limiter
            binding.seekLimiter.progress = ((cfg.rpmLimiter - 4000) / 500).coerceIn(0, 24)
            binding.tvLimiterValue.text = "${cfg.rpmLimiter} RPM"

            // SCR pulse
            val us = CdiConfig.tickToUs(cfg.scrPulse)
            val scrProg = ((us - 100) / 50).coerceIn(0, 38)
            binding.seekScr.progress = scrProg
            binding.tvScrValue.text = "${us}µs (${cfg.scrPulse} tick)"

            // Rumble RPM
            val rblProg = if (cfg.rumbleRpm == 0) 0
                          else ((cfg.rumbleRpm - 400) / 100).coerceIn(1, 26)
            binding.seekRumble.progress = rblProg
            binding.tvRumbleValue.text = if (cfg.rumbleRpm == 0) "OFF"
                                         else "${cfg.rumbleRpm} RPM"

            // Rumble skip
            binding.seekRumbleSkip.progress = (cfg.rumbleSkip - 2).coerceIn(0, 6)
            binding.tvRumbleSkipValue.text = "Setiap ${cfg.rumbleSkip} spark"

            isUpdating = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
