package com.cdi.tuner.data

data class CdiConfig(
    val advanceMap: IntArray = IntArray(32) { defaultAdvanceMap[it] },
    val rpmLimiter: Int = 12000,
    val pulserAngle: Int = 82,
    val scrPulse: Int = 1000,    // 200-4000 tick (100us-2000us)
    val rumbleRpm: Int = 0,      // 0=off, 500-3000 RPM
    val rumbleSkip: Int = 3      // 2-8 spark skip
) {
    companion object {
        val defaultAdvanceMap = intArrayOf(
            0, 8, 15, 20, 24, 28, 30, 32,
            34,34, 34, 34, 34, 34, 34, 34,
            34,34, 34, 34, 34, 32, 30, 27,
            23,19, 17, 15, 15, 15, 10, 10
        )

        fun rpmLabelForIndex(index: Int): String {
            val rpm = index * 500
            return if (rpm == 0) "Idle" else "$rpm"
        }

        // Konversi tick ke microsecond
        fun tickToUs(tick: Int) = tick / 2  // 1 tick = 0.5us

        // Konversi microsecond ke tick
        fun usToTick(us: Int) = us * 2
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is CdiConfig) return false
        return advanceMap.contentEquals(other.advanceMap) &&
               rpmLimiter == other.rpmLimiter &&
               pulserAngle == other.pulserAngle &&
               scrPulse == other.scrPulse &&
               rumbleRpm == other.rumbleRpm &&
               rumbleSkip == other.rumbleSkip
    }

    override fun hashCode(): Int {
        var result = advanceMap.contentHashCode()
        result = 31 * result + rpmLimiter
        result = 31 * result + pulserAngle
        result = 31 * result + scrPulse
        result = 31 * result + rumbleRpm
        result = 31 * result + rumbleSkip
        return result
    }
}
