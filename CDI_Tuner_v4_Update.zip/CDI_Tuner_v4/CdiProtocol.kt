package com.cdi.tuner.protocol

import com.cdi.tuner.data.CdiConfig

object CdiProtocol {

    sealed class Message {
        data class Rpm(val value: Int, val activeMap: Int = 1) : Message()
        data class Config(val config: CdiConfig) : Message()
        object Ok : Message()
        object Err : Message()
    }

    private var pM1: IntArray? = null
    private var pM2: IntArray? = null
    private var pM3: IntArray? = null
    private var pLim: Int? = null
    private var pAng: Int? = null
    private var pPka: Int? = null
    private var pDlt: Int? = null
    private var pEdg: Int? = null
    private var pScr: Int? = null
    private var pRbl: Int? = null
    private var pRsk: Int? = null
    private var pAct: Int? = null

    private var lastRpmActiveMap = 1

    fun parseLine(line: String): Message? {
        val t = line.trim()
        return when {
            t.startsWith("RPM:") -> {
                val rpm = t.removePrefix("RPM:").toIntOrNull() ?: return null
                Message.Rpm(rpm, lastRpmActiveMap)
            }
            t.startsWith("ACT:") && t.length < 10 -> {
                // ACT standalone (dari RPM report)
                lastRpmActiveMap = t.removePrefix("ACT:").toIntOrNull() ?: 1
                null
            }
            t.startsWith("M1:") -> {
                pM1 = parseMap(t.removePrefix("M1:")); tryBuild()
            }
            t.startsWith("M2:") -> {
                pM2 = parseMap(t.removePrefix("M2:")); tryBuild()
            }
            t.startsWith("M3:") -> {
                pM3 = parseMap(t.removePrefix("M3:")); tryBuild()
            }
            t.startsWith("LIM:") -> { pLim = t.removePrefix("LIM:").toIntOrNull(); tryBuild() }
            t.startsWith("ANG:") -> { pAng = t.removePrefix("ANG:").toIntOrNull(); tryBuild() }
            t.startsWith("PKA:") -> { pPka = t.removePrefix("PKA:").toIntOrNull(); tryBuild() }
            t.startsWith("DLT:") -> { pDlt = t.removePrefix("DLT:").toIntOrNull(); tryBuild() }
            t.startsWith("EDG:") -> { pEdg = t.removePrefix("EDG:").toIntOrNull(); tryBuild() }
            t.startsWith("SCR:") -> { pScr = t.removePrefix("SCR:").toIntOrNull(); tryBuild() }
            t.startsWith("RBL:") -> { pRbl = t.removePrefix("RBL:").toIntOrNull(); tryBuild() }
            t.startsWith("RSK:") -> { pRsk = t.removePrefix("RSK:").toIntOrNull(); tryBuild() }
            t.startsWith("ACT:") -> { pAct = t.removePrefix("ACT:").toIntOrNull(); tryBuild() }
            t == "OK"  -> Message.Ok
            t == "ERR" -> Message.Err
            else -> null
        }
    }

    private fun parseMap(csv: String): IntArray? {
        val values = csv.split(",").mapNotNull { it.trim().toIntOrNull() }
        return if (values.size == 32) values.toIntArray() else null
    }

    private fun tryBuild(): Message.Config? {
        val m1  = pM1  ?: return null
        val m2  = pM2  ?: return null
        val m3  = pM3  ?: return null
        val lim = pLim ?: return null
        val ang = pAng ?: return null
        val pka = pPka ?: return null
        val dlt = pDlt ?: return null
        val edg = pEdg ?: return null
        val scr = pScr ?: return null
        val rbl = pRbl ?: return null
        val rsk = pRsk ?: return null
        val act = pAct ?: return null
        pM1=null; pM2=null; pM3=null
        pLim=null; pAng=null; pPka=null; pDlt=null
        pEdg=null; pScr=null; pRbl=null; pRsk=null; pAct=null
        return Message.Config(CdiConfig(m1,m2,m3,lim,ang,pka,dlt,edg,scr,rbl,rsk,act))
    }

    fun resetPartial() {
        pM1=null; pM2=null; pM3=null
        pLim=null; pAng=null; pPka=null; pDlt=null
        pEdg=null; pScr=null; pRbl=null; pRsk=null; pAct=null
    }

    fun buildGet()  = "GET\r\n"
    fun buildSave() = "SAVE\r\n"
    fun buildSetLimiter(rpm: Int)    = "LIM:$rpm\r\n"
    fun buildSetAngle(deg: Int)      = "ANG:$deg\r\n"
    fun buildSetPickupAngle(deg: Int) = "PKA:$deg\r\n"
    fun buildSetDelta(delta: Int)    = "DLT:$delta\r\n"
    fun buildSetEdge(edge: Int)      = "EDG:$edge\r\n"
    fun buildSetScrPulse(tick: Int)  = "SCR:$tick\r\n"
    fun buildSetRumbleRpm(rpm: Int)  = "RBL:$rpm\r\n"
    fun buildSetRumbleSkip(n: Int)   = "RSK:$n\r\n"
    fun buildSetActiveMap(map: Int)  = "ACT:$map\r\n"
    fun buildSetMap1(map: IntArray)  = "M1:${map.joinToString(",")}\r\n"
    fun buildSetMap2(map: IntArray)  = "M2:${map.joinToString(",")}\r\n"
    fun buildSetMap3(map: IntArray)  = "M3:${map.joinToString(",")}\r\n"

    fun buildFullConfig(config: CdiConfig): List<String> = listOf(
        buildSetMap1(config.map1),
        buildSetMap2(config.map2),
        buildSetMap3(config.map3),
        buildSetLimiter(config.rpmLimiter),
        buildSetAngle(config.pulserAngle),
        buildSetPickupAngle(config.pickupAngle),
        buildSetDelta(config.delta),
        buildSetEdge(config.edge),
        buildSetScrPulse(config.scrPulse),
        buildSetRumbleRpm(config.rumbleRpm),
        buildSetRumbleSkip(config.rumbleSkip),
        buildSetActiveMap(config.activeMap),
        buildSave()
    )
}
