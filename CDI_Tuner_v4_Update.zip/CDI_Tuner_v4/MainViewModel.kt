package com.cdi.tuner.viewmodel

import android.app.Application
import android.bluetooth.BluetoothDevice
import androidx.lifecycle.*
import com.cdi.tuner.connection.ConnectionManager
import com.cdi.tuner.connection.ConnectionState
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.data.Preset
import com.cdi.tuner.data.PresetDatabase
import com.cdi.tuner.protocol.CdiProtocol
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val connectionManager = ConnectionManager(application)
    private val db = PresetDatabase.getInstance(application)

    val connectionState = connectionManager.state.asLiveData()

    private val _rpm = MutableLiveData(0)
    val rpm: LiveData<Int> = _rpm

    private val _activeMapIndicator = MutableLiveData(1)
    val activeMapIndicator: LiveData<Int> = _activeMapIndicator

    private val _config = MutableLiveData(CdiConfig())
    val config: LiveData<CdiConfig> = _config

    private val _editConfig = MutableLiveData(CdiConfig())
    val editConfig: LiveData<CdiConfig> = _editConfig

    private val _statusMessage = MutableLiveData<String?>()
    val statusMessage: LiveData<String?> = _statusMessage

    val presets: LiveData<List<Preset>> = db.presetDao().getAll().asLiveData()

    init {
        viewModelScope.launch {
            connectionManager.incomingLines.collect { line ->
                when (val msg = CdiProtocol.parseLine(line)) {
                    is CdiProtocol.Message.Rpm -> {
                        _rpm.postValue(msg.value)
                        _activeMapIndicator.postValue(msg.activeMap)
                    }
                    is CdiProtocol.Message.Config -> {
                        _config.postValue(msg.config)
                        _editConfig.postValue(msg.config.copy())
                        _statusMessage.postValue("Config diterima dari CDI")
                    }
                    is CdiProtocol.Message.Ok  -> _statusMessage.postValue("Berhasil")
                    is CdiProtocol.Message.Err -> _statusMessage.postValue("Error dari CDI")
                    else -> {}
                }
            }
        }
        viewModelScope.launch {
            connectionManager.state.collect { state ->
                if (state is ConnectionState.Connected) {
                    kotlinx.coroutines.delay(600)
                    requestConfig()
                }
            }
        }
    }

    // ── Connection ───────────────────────────────────────
    fun connectBluetooth(device: BluetoothDevice) = connectionManager.connectBluetooth(device)
    fun connectUsb() = connectionManager.connectUsb()
    fun disconnect() = connectionManager.disconnect()
    fun getPairedDevices() = connectionManager.getPairedDevices()

    fun requestConfig() = connectionManager.send(CdiProtocol.buildGet())

    fun sendFullConfig() {
        val cfg = _editConfig.value ?: return
        viewModelScope.launch {
            CdiProtocol.buildFullConfig(cfg).forEach { cmd ->
                connectionManager.send(cmd)
                kotlinx.coroutines.delay(80)
            }
            _statusMessage.value = "Config dikirim ke CDI"
        }
    }

    fun sendLimiter(rpm: Int) {
        connectionManager.send(CdiProtocol.buildSetLimiter(rpm))
        connectionManager.send(CdiProtocol.buildSave())
        updateEditLimiter(rpm)
    }

    fun sendPulserAngle(deg: Int) {
        connectionManager.send(CdiProtocol.buildSetAngle(deg))
        connectionManager.send(CdiProtocol.buildSave())
        updateEditAngle(deg)
    }

    fun sendScrPulse(tick: Int) {
        connectionManager.send(CdiProtocol.buildSetScrPulse(tick))
        connectionManager.send(CdiProtocol.buildSave())
        updateEditScrPulse(tick)
    }

    fun sendRumble(rpm: Int, skip: Int) {
        connectionManager.send(CdiProtocol.buildSetRumbleRpm(rpm))
        connectionManager.send(CdiProtocol.buildSetRumbleSkip(skip))
        connectionManager.send(CdiProtocol.buildSave())
    }

    // ── Edit Config ──────────────────────────────────────
    fun updateEditMapValue(mapNum: Int, index: Int, value: Int) {
        val c = _editConfig.value ?: return
        val v = value.coerceIn(0, 45)
        _editConfig.value = when (mapNum) {
            1 -> { val m = c.map1.copyOf(); m[index] = v; c.copy(map1 = m) }
            2 -> { val m = c.map2.copyOf(); m[index] = v; c.copy(map2 = m) }
            3 -> { val m = c.map3.copyOf(); m[index] = v; c.copy(map3 = m) }
            else -> c
        }
    }

    fun updateEditLimiter(rpm: Int)      { _editConfig.value = _editConfig.value?.copy(rpmLimiter = rpm) }
    fun updateEditAngle(deg: Int)        { _editConfig.value = _editConfig.value?.copy(pulserAngle = deg) }
    fun updateEditPickupAngle(deg: Int)  { _editConfig.value = _editConfig.value?.copy(pickupAngle = deg) }
    fun updateEditDelta(delta: Int)      { _editConfig.value = _editConfig.value?.copy(delta = delta) }
    fun updateEditEdge(edge: Int)        { _editConfig.value = _editConfig.value?.copy(edge = edge) }
    fun updateEditScrPulse(tick: Int)    { _editConfig.value = _editConfig.value?.copy(scrPulse = tick) }
    fun updateEditRumbleRpm(rpm: Int)    { _editConfig.value = _editConfig.value?.copy(rumbleRpm = rpm) }
    fun updateEditRumbleSkip(skip: Int)  { _editConfig.value = _editConfig.value?.copy(rumbleSkip = skip) }
    fun updateEditActiveMap(map: Int)    { _editConfig.value = _editConfig.value?.copy(activeMap = map) }

    fun resetEditToLast()    { _editConfig.value = _config.value?.copy() ?: CdiConfig() }
    fun resetEditToDefault() { _editConfig.value = CdiConfig() }
    fun loadConfig(config: CdiConfig) {
        _editConfig.value = config.copy()
        _statusMessage.value = "Config dimuat"
    }

    // ── Preset ───────────────────────────────────────────
    fun savePreset(name: String) {
        val cfg = _editConfig.value ?: return
        viewModelScope.launch {
            val m1 = JSONArray().apply { cfg.map1.forEach { put(it) } }.toString()
            val m2 = JSONArray().apply { cfg.map2.forEach { put(it) } }.toString()
            val m3 = JSONArray().apply { cfg.map3.forEach { put(it) } }.toString()
            db.presetDao().insert(Preset(
                name = name,
                map1Json = m1, map2Json = m2, map3Json = m3,
                rpmLimiter = cfg.rpmLimiter,
                pulserAngle = cfg.pulserAngle,
                pickupAngle = cfg.pickupAngle,
                delta = cfg.delta,
                edge = cfg.edge,
                scrPulse = cfg.scrPulse,
                rumbleRpm = cfg.rumbleRpm,
                rumbleSkip = cfg.rumbleSkip,
                activeMap = cfg.activeMap
            ))
            _statusMessage.value = "Preset '$name' tersimpan"
        }
    }

    fun loadPreset(preset: Preset) {
        fun parseMap(json: String) = JSONArray(json).let { arr -> IntArray(32) { arr.getInt(it) } }
        _editConfig.value = CdiConfig(
            parseMap(preset.map1Json),
            parseMap(preset.map2Json),
            parseMap(preset.map3Json),
            preset.rpmLimiter, preset.pulserAngle,
            preset.pickupAngle, preset.delta, preset.edge,
            preset.scrPulse, preset.rumbleRpm, preset.rumbleSkip,
            preset.activeMap
        )
        _statusMessage.value = "Preset '${preset.name}' dimuat"
    }

    fun deletePreset(preset: Preset) {
        viewModelScope.launch { db.presetDao().delete(preset) }
    }

    fun clearStatus() { _statusMessage.value = null }

    override fun onCleared() {
        super.onCleared()
        connectionManager.dispose()
    }
}
