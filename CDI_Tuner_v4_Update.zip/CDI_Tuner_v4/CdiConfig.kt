package com.cdi.tuner.data

data class CdiConfig(
    val map1: IntArray = IntArray(32) { defaultMap1[it] },  // Harian
    val map2: IntArray = IntArray(32) { defaultMap2[it] },  // Touring
    val map3: IntArray = IntArray(32) { defaultMap3[it] },  // Racing
    val rpmLimiter: Int = 12000,
    val pulserAngle: Int = 82,
    val pickupAngle: Int = 0,       // Offset sensor pickup 0-30°
    val delta: Int = 0,             // Fine tune -30 sampai +30°
    val edge: Int = 0,              // 0=falling, 1=rising
    val scrPulse: Int = 1000,
    val rumbleRpm: Int = 0,
    val rumbleSkip: Int = 3,
    val activeMap: Int = 1          // 1=Harian, 2=Touring, 3=Racing
) {
    // Shortcut ke map yang sedang aktif
    val advanceMap: IntArray get() = when (activeMap) {
        2 -> map2
        3 -> map3
        else -> map1
    }

    companion object {
        val defaultMap1 = intArrayOf(  // Harian
             0, 8,15,20,24,28,30,32,
            34,34,34,34,34,34,34,34,
            34,34,34,34,34,32,30,27,
            23,19,17,15,15,15,10,10
        )
        val defaultMap2 = intArrayOf(  // Touring
             0, 6,12,18,22,26,28,30,
            32,32,32,32,32,32,32,32,
            32,32,32,30,28,26,24,22,
            20,17,15,12,12,12, 8, 8
        )
        val defaultMap3 = intArrayOf(  // Racing
             0, 5,12,18,24,30,34,36,
            38,40,40,40,40,40,38,36,
            34,32,30,28,26,24,22,20,
            18,15,12,10,10,10, 8, 8
        )

        fun rpmLabelForIndex(index: Int): String {
            return if (index == 0) "Idle" else "${index * 500}"
        }

        fun tickToUs(tick: Int) = tick / 2
        fun usToTick(us: Int)   = us * 2

        fun mapNameForIndex(index: Int) = when (index) {
            1 -> "Map 1 - Harian"
            2 -> "Map 2 - Touring"
            3 -> "Map 3 - Racing"
            else -> "Map 1 - Harian"
        }

        fun edgeName(edge: Int) = if (edge == 0) "Falling Edge" else "Rising Edge"
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is CdiConfig) return false
        return map1.contentEquals(other.map1) &&
               map2.contentEquals(other.map2) &&
               map3.contentEquals(other.map3) &&
               rpmLimiter == other.rpmLimiter &&
               pulserAngle == other.pulserAngle &&
               pickupAngle == other.pickupAngle &&
               delta == other.delta &&
               edge == other.edge &&
               scrPulse == other.scrPulse &&
               rumbleRpm == other.rumbleRpm &&
               rumbleSkip == other.rumbleSkip &&
               activeMap == other.activeMap
    }

    override fun hashCode(): Int {
        var result = map1.contentHashCode()
        result = 31 * result + map2.contentHashCode()
        result = 31 * result + map3.contentHashCode()
        result = 31 * result + rpmLimiter
        result = 31 * result + pulserAngle
        result = 31 * result + pickupAngle
        result = 31 * result + delta
        result = 31 * result + edge
        result = 31 * result + scrPulse
        result = 31 * result + rumbleRpm
        result = 31 * result + rumbleSkip
        result = 31 * result + activeMap
        return result
    }
}
