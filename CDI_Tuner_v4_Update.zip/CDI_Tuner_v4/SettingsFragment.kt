package com.cdi.tuner.ui.settings

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.cdi.tuner.R
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.databinding.FragmentSettingsBinding
import com.cdi.tuner.viewmodel.MainViewModel

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private var isUpdating = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        FragmentSettingsBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupInputListeners()
        setupButtons()
        observeViewModel()
    }

    private fun addTextWatcher(et: EditText, onChanged: (String) -> Unit) {
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!isUpdating) onChanged(s.toString())
            }
        })
    }

    private fun setupInputListeners() {
        // Pulser Angle
        addTextWatcher(binding.etAngle) { s ->
            s.toIntOrNull()?.let { if (it in 50..95) viewModel.updateEditAngle(it) }
        }
        // Pickup Angle
        addTextWatcher(binding.etPickupAngle) { s ->
            s.toIntOrNull()?.let { if (it in 0..30) viewModel.updateEditPickupAngle(it) }
        }
        // Delta
        addTextWatcher(binding.etDelta) { s ->
            s.toIntOrNull()?.let { if (it in -30..30) viewModel.updateEditDelta(it) }
        }
        // RPM Limiter
        addTextWatcher(binding.etLimiter) { s ->
            s.toIntOrNull()?.let { if (it in 1000..16000) viewModel.updateEditLimiter(it) }
        }
        // SCR Pulse (dalam µs, convert ke tick)
        addTextWatcher(binding.etScr) { s ->
            s.toIntOrNull()?.let {
                if (it in 100..2000) viewModel.updateEditScrPulse(CdiConfig.usToTick(it))
            }
        }
        // Rumble RPM
        addTextWatcher(binding.etRumbleRpm) { s ->
            s.toIntOrNull()?.let {
                if (it == 0 || it in 500..3000) viewModel.updateEditRumbleRpm(it)
            }
        }
        // Rumble Skip
        addTextWatcher(binding.etRumbleSkip) { s ->
            s.toIntOrNull()?.let { if (it in 2..8) viewModel.updateEditRumbleSkip(it) }
        }

        // Edge selector (radio)
        binding.rgEdge.setOnCheckedChangeListener { _, checkedId ->
            if (!isUpdating) {
                val edge = if (checkedId == R.id.rbFalling) 0 else 1
                viewModel.updateEditEdge(edge)
            }
        }

        // Active Map selector (radio)
        binding.rgActiveMap.setOnCheckedChangeListener { _, checkedId ->
            if (!isUpdating) {
                val map = when (checkedId) {
                    R.id.rbMap2 -> 2
                    R.id.rbMap3 -> 3
                    else -> 1
                }
                viewModel.updateEditActiveMap(map)
            }
        }
    }

    private fun setupButtons() {
        binding.btnSendSettings.setOnClickListener {
            viewModel.sendFullConfig()
        }
        binding.btnRevertSettings.setOnClickListener {
            viewModel.resetEditToLast()
        }
        binding.btnResetDefault.setOnClickListener {
            viewModel.resetEditToDefault()
        }
    }

    private fun observeViewModel() {
        viewModel.editConfig.observe(viewLifecycleOwner) { cfg ->
            isUpdating = true

            binding.etAngle.setText(cfg.pulserAngle.toString())
            binding.etPickupAngle.setText(cfg.pickupAngle.toString())
            binding.etDelta.setText(cfg.delta.toString())
            binding.etLimiter.setText(cfg.rpmLimiter.toString())
            binding.etScr.setText(CdiConfig.tickToUs(cfg.scrPulse).toString())
            binding.etRumbleRpm.setText(cfg.rumbleRpm.toString())
            binding.etRumbleSkip.setText(cfg.rumbleSkip.toString())

            // Edge
            if (cfg.edge == 0) binding.rbFalling.isChecked = true
            else binding.rbRising.isChecked = true

            // Active map
            when (cfg.activeMap) {
                2 -> binding.rbMap2.isChecked = true
                3 -> binding.rbMap3.isChecked = true
                else -> binding.rbMap1.isChecked = true
            }

            // Info total timing
            val totalRef = cfg.pulserAngle + cfg.pickupAngle + cfg.delta
            binding.tvTimingInfo.text = "Referensi timing: ${totalRef}° BTDC\n" +
                "(Pulser ${cfg.pulserAngle}° + Pickup ${cfg.pickupAngle}° + Delta ${cfg.delta}°)"

            isUpdating = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
