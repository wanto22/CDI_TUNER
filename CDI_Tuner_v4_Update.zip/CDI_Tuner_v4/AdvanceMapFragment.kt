package com.cdi.tuner.ui.advancemap

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.cdi.tuner.R
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.databinding.FragmentAdvanceMapBinding
import com.cdi.tuner.viewmodel.MainViewModel
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter

class AdvanceMapFragment : Fragment() {

    private var _binding: FragmentAdvanceMapBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    private val editTexts1 = arrayOfNulls<EditText>(32)  // Map 1
    private val editTexts2 = arrayOfNulls<EditText>(32)  // Map 2
    private val editTexts3 = arrayOfNulls<EditText>(32)  // Map 3
    private var isUpdating = false
    private var currentMapView = 1  // 1, 2, atau 3
    private var showingGraph = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        FragmentAdvanceMapBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        buildAllTables()
        setupChart()
        setupButtons()
        observeViewModel()
    }

    private fun buildAllTables() {
        buildTable(binding.tableMap1, editTexts1, 1)
        buildTable(binding.tableMap2, editTexts2, 2)
        buildTable(binding.tableMap3, editTexts3, 3)
        showMap(1)
    }

    private fun showMap(map: Int) {
        currentMapView = map
        binding.tableMap1.visibility = if (map == 1 && !showingGraph) View.VISIBLE else View.GONE
        binding.tableMap2.visibility = if (map == 2 && !showingGraph) View.VISIBLE else View.GONE
        binding.tableMap3.visibility = if (map == 3 && !showingGraph) View.VISIBLE else View.GONE
        binding.chartAdvance.visibility = if (showingGraph) View.VISIBLE else View.GONE

        binding.btnMap1.isSelected = map == 1
        binding.btnMap2.isSelected = map == 2
        binding.btnMap3.isSelected = map == 3

        val cfg = viewModel.editConfig.value ?: return
        if (showingGraph) updateChart(cfg)
    }

    private fun buildTable(table: TableLayout, ets: Array<EditText?>, mapNum: Int) {
        table.removeAllViews()

        // Header
        val header = TableRow(requireContext())
        header.addView(makeCell("RPM", true))
        header.addView(makeCell("Advance°", true))
        table.addView(header)

        for (i in 0 until 32) {
            val row = TableRow(requireContext())

            val tvRpm = TextView(requireContext()).apply {
                text = if (i == 0) "Idle" else "${i * 500}"
                setPadding(12, 8, 12, 8)
                textSize = 12f
                setTextColor(when {
                    i <= 6  -> Color.parseColor("#4CAF50")
                    i <= 16 -> Color.parseColor("#FF9800")
                    else    -> Color.parseColor("#F44336")
                })
            }

            val et = EditText(requireContext()).apply {
                layoutParams = TableRow.LayoutParams(140, ViewGroup.LayoutParams.WRAP_CONTENT)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                gravity = android.view.Gravity.CENTER
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(8, 6, 8, 6)
                setTextColor(Color.WHITE)
                setBackgroundResource(android.R.color.transparent)
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (isUpdating) return
                        val v = s.toString().toIntOrNull() ?: return
                        if (v in 0..45) {
                            viewModel.updateEditMapValue(mapNum, i, v)
                            val cfg = viewModel.editConfig.value ?: return
                            if (showingGraph) updateChart(cfg)
                        }
                    }
                })
            }
            ets[i] = et

            row.addView(tvRpm)
            row.addView(et)
            table.addView(row)
        }
    }

    private fun makeCell(text: String, header: Boolean): TextView {
        return TextView(requireContext()).apply {
            this.text = text
            setPadding(12, 8, 12, 8)
            textSize = if (header) 12f else 13f
            if (header) {
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(Color.parseColor("#B0B0B0"))
                setBackgroundColor(Color.parseColor("#2C2C2C"))
            }
        }
    }

    private fun setupChart() {
        binding.chartAdvance.apply {
            description.isEnabled = false
            legend.isEnabled = true
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(false)
            setBackgroundColor(Color.parseColor("#1E1E1E"))
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                textColor = Color.GRAY
                setDrawGridLines(false)
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) =
                        if (value == 0f) "Idle" else "${(value * 500).toInt()}"
                }
            }
            axisLeft.apply {
                axisMinimum = 0f
                axisMaximum = 50f
                textColor = Color.GRAY
                gridColor = Color.parseColor("#333333")
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) = "${value.toInt()}°"
                }
            }
            axisRight.isEnabled = false
        }
    }

    private fun updateChart(cfg: CdiConfig) {
        val maps = listOf(
            Triple(cfg.map1, "Harian", Color.parseColor("#4CAF50")),
            Triple(cfg.map2, "Touring", Color.parseColor("#FF9800")),
            Triple(cfg.map3, "Racing", Color.parseColor("#F44336"))
        )
        val dataSets = maps.map { (map, label, color) ->
            val entries = map.mapIndexed { i, v -> Entry(i.toFloat(), v.toFloat()) }
            LineDataSet(entries, label).apply {
                this.color = color
                fillColor = color
                fillAlpha = 15
                setDrawFilled(true)
                setDrawCircles(false)
                setDrawValues(false)
                lineWidth = 2f
                mode = LineDataSet.Mode.HORIZONTAL_BEZIER
            }
        }
        binding.chartAdvance.data = LineData(dataSets)
        binding.chartAdvance.invalidate()
    }

    private fun setupButtons() {
        binding.btnMap1.setOnClickListener { showingGraph = false; showMap(1) }
        binding.btnMap2.setOnClickListener { showingGraph = false; showMap(2) }
        binding.btnMap3.setOnClickListener { showingGraph = false; showMap(3) }
        binding.btnToggleView.setOnClickListener {
            showingGraph = !showingGraph
            binding.btnToggleView.text = if (showingGraph) "Tabel" else "Grafik"
            showMap(currentMapView)
        }
        binding.btnSendMap.setOnClickListener { viewModel.sendFullConfig() }
        binding.btnRevert.setOnClickListener { viewModel.resetEditToLast() }
        binding.btnReset.setOnClickListener { viewModel.resetEditToDefault() }
    }

    private fun observeViewModel() {
        viewModel.editConfig.observe(viewLifecycleOwner) { cfg ->
            isUpdating = true
            for (i in 0 until 32) {
                editTexts1[i]?.setText(cfg.map1[i].toString())
                editTexts2[i]?.setText(cfg.map2[i].toString())
                editTexts3[i]?.setText(cfg.map3[i].toString())
            }
            isUpdating = false
            if (showingGraph) updateChart(cfg)

            // Highlight map aktif
            val act = cfg.activeMap
            binding.btnMap1.alpha = if (act == 1) 1f else 0.6f
            binding.btnMap2.alpha = if (act == 2) 1f else 0.6f
            binding.btnMap3.alpha = if (act == 3) 1f else 0.6f
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
