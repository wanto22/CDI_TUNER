package com.cdi.tuner.ui.monitor

import android.graphics.Color
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.cdi.tuner.R
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.databinding.FragmentMonitorBinding
import com.cdi.tuner.viewmodel.MainViewModel
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter

class MonitorFragment : Fragment() {

    private var _binding: FragmentMonitorBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    private val rpmHistory   = ArrayDeque<Float>(120)
    private val timeHistory  = ArrayDeque<Float>(120)
    private var timeCounter  = 0f
    private var maxRpmSeen   = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        FragmentMonitorBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupChart()
        observeViewModel()
        binding.btnRefresh.setOnClickListener { viewModel.requestConfig() }
        binding.btnResetMax.setOnClickListener {
            maxRpmSeen = 0
            binding.tvMaxRpm.text = "Max: 0 RPM"
        }
    }

    private fun setupChart() {
        binding.chartRpm.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(false)
            setDrawGridBackground(false)
            legend.isEnabled = false
            setBackgroundColor(Color.parseColor("#1E1E1E"))

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawLabels(true)
                setDrawGridLines(false)
                textColor = Color.GRAY
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) = "${value.toInt()}s"
                }
            }
            axisLeft.apply {
                axisMinimum = 0f
                axisMaximum = 16000f
                gridColor = Color.parseColor("#333333")
                textColor = Color.GRAY
                granularity = 2000f
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) = "${value.toInt()}"
                }
                // Tambah limit line untuk RPM limiter
                setDrawLimitLinesBehindData(true)
            }
            axisRight.isEnabled = false
        }
    }

    private fun updateChart(rpm: Int) {
        if (rpmHistory.size >= 120) {
            rpmHistory.removeFirst()
            timeHistory.removeFirst()
        }
        rpmHistory.addLast(rpm.toFloat())
        timeHistory.addLast(timeCounter)
        timeCounter += 0.25f // update setiap ~250ms

        val entries = rpmHistory.mapIndexed { i, v -> Entry(timeHistory[i], v) }
        val dataSet = LineDataSet(entries, "RPM").apply {
            // Warna gradient berdasarkan RPM
            color = when {
                rpm >= (viewModel.config.value?.rpmLimiter ?: 12000) -> Color.RED
                rpm >= (viewModel.config.value?.rpmLimiter ?: 12000) * 0.85f -> Color.parseColor("#FF9800")
                else -> Color.parseColor("#4CAF50")
            }
            fillColor = color
            fillAlpha = 30
            setDrawFilled(true)
            setDrawCircles(false)
            setDrawValues(false)
            lineWidth = 2.5f
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }
        binding.chartRpm.data = LineData(dataSet)
        binding.chartRpm.invalidate()
    }

    private fun observeViewModel() {
        viewModel.rpm.observe(viewLifecycleOwner) { rpm ->
            // RPM utama
            binding.tvRpm.text = rpm.toString()
            updateChart(rpm)

            // Max RPM tracker
            if (rpm > maxRpmSeen) {
                maxRpmSeen = rpm
                binding.tvMaxRpm.text = "Max: $maxRpmSeen RPM"
            }

            // Advance aktif
            val cfg = viewModel.config.value ?: CdiConfig()
            val index = (rpm / 500).coerceIn(0, 31)
            binding.tvAdvance.text = "${cfg.advanceMap[index]}°"

            // RPM bar
            binding.rpmBar.progress = (rpm * 100 / 16000).coerceIn(0, 100)

            // Warna RPM
            val limiter = cfg.rpmLimiter
            val color = when {
                rpm >= limiter -> requireContext().getColor(R.color.rpm_over_limit)
                rpm >= limiter * 0.85f -> requireContext().getColor(R.color.rpm_warning)
                else -> requireContext().getColor(R.color.rpm_normal)
            }
            binding.tvRpm.setTextColor(color)
            binding.rpmBar.progressTintList =
                android.content.res.ColorStateList.valueOf(color)
        }

        viewModel.config.observe(viewLifecycleOwner) { cfg ->
            binding.tvLimiter.text = "Limiter: ${cfg.rpmLimiter} RPM"
            binding.tvAngle.text = "Pulser: ${cfg.pulserAngle}°"

            // Update limit line di chart
            binding.chartRpm.axisLeft.removeAllLimitLines()
            val ll = com.github.mikephil.charting.components.LimitLine(
                cfg.rpmLimiter.toFloat(), "Limiter"
            ).apply {
                lineWidth = 1.5f
                lineColor = Color.RED
                enableDashedLine(10f, 5f, 0f)
                labelPosition = com.github.mikephil.charting.components.LimitLine.LimitLabelPosition.RIGHT_TOP
                textColor = Color.RED
                textSize = 9f
            }
            binding.chartRpm.axisLeft.addLimitLine(ll)
            binding.chartRpm.invalidate()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
