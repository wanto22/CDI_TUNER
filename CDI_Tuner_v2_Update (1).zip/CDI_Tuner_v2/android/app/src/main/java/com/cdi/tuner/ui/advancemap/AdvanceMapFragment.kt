package com.cdi.tuner.ui.advancemap

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.cdi.tuner.R
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.databinding.FragmentAdvanceMapBinding
import com.cdi.tuner.viewmodel.MainViewModel
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.LimitLine
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.listener.OnChartValueSelectedListener

class AdvanceMapFragment : Fragment() {

    private var _binding: FragmentAdvanceMapBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    private val editTexts = arrayOfNulls<EditText>(32)
    private var isUpdatingFromViewModel = false
    private var showingGraph = false  // Toggle table/graph

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        FragmentAdvanceMapBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        buildTable()
        setupChart()
        setupButtons()
        observeViewModel()
    }

    // ─── Toggle Table / Graph ─────────────────────────────
    private fun toggleView() {
        showingGraph = !showingGraph
        if (showingGraph) {
            binding.tableScroll.visibility = View.GONE
            binding.chartAdvance.visibility = View.VISIBLE
            binding.btnToggleView.text = "📋 Tampilkan Tabel"
        } else {
            binding.tableScroll.visibility = View.VISIBLE
            binding.chartAdvance.visibility = View.GONE
            binding.btnToggleView.text = "📈 Tampilkan Grafik"
        }
    }

    // ─── Build table 32 baris ─────────────────────────────
    private fun buildTable() {
        val table = binding.tableMap
        table.removeAllViews()

        // Header
        val header = TableRow(requireContext()).apply {
            addView(makeHeaderCell("RPM"))
            addView(makeHeaderCell("Advance (°)"))
            addView(makeHeaderCell("Slider"))
        }
        table.addView(header)

        for (i in 0 until 32) {
            val row = TableRow(requireContext())

            // Label RPM dengan warna zone
            val tvRpm = TextView(requireContext()).apply {
                text = if (i == 0) "Idle" else "${i * 500}"
                setPadding(16, 8, 16, 8)
                // Warna zone RPM
                setTextColor(when {
                    i <= 6  -> Color.parseColor("#4CAF50")  // Hijau - rendah
                    i <= 16 -> Color.parseColor("#FF9800")  // Orange - mid
                    else    -> Color.parseColor("#F44336")  // Merah - tinggi
                })
            }

            val et = EditText(requireContext()).apply {
                layoutParams = TableRow.LayoutParams(120, ViewGroup.LayoutParams.WRAP_CONTENT)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                gravity = android.view.Gravity.CENTER
                setPadding(8, 4, 8, 4)
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (isUpdatingFromViewModel) return
                        val v = s.toString().toIntOrNull() ?: return
                        if (v in 0..45) {
                            viewModel.updateEditAdvanceMap(i, v)
                            updateChart(viewModel.editConfig.value ?: CdiConfig())
                        }
                    }
                })
            }
            editTexts[i] = et

            val seek = SeekBar(requireContext()).apply {
                max = 45
                layoutParams = TableRow.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                progressTintList = android.content.res.ColorStateList.valueOf(when {
                    i <= 6  -> Color.parseColor("#4CAF50")
                    i <= 16 -> Color.parseColor("#FF9800")
                    else    -> Color.parseColor("#F44336")
                })
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) et.setText(progress.toString())
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            et.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val v = s.toString().toIntOrNull() ?: return
                    if (seek.progress != v) seek.progress = v.coerceIn(0, 45)
                }
            })

            row.addView(tvRpm)
            row.addView(et)
            row.addView(seek)
            table.addView(row)
        }
    }

    private fun makeHeaderCell(text: String) = TextView(requireContext()).apply {
        this.text = text
        setPadding(16, 12, 16, 12)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setBackgroundColor(requireContext().getColor(R.color.table_header))
        setTextColor(requireContext().getColor(R.color.table_header_text))
    }

    // ─── Chart ────────────────────────────────────────────
    private fun setupChart() {
        binding.chartAdvance.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(false)
            setBackgroundColor(Color.parseColor("#1E1E1E"))

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                granularity = 1f
                labelCount = 8
                textColor = Color.GRAY
                setDrawGridLines(false)
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) =
                        if (value == 0f) "Idle" else "${(value * 500).toInt()}"
                }
            }
            axisLeft.apply {
                axisMinimum = 0f
                axisMaximum = 50f
                granularity = 5f
                textColor = Color.GRAY
                gridColor = Color.parseColor("#333333")
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) = "${value.toInt()}°"
                }
            }
            axisRight.isEnabled = false

            // Tap pada titik grafik → update nilai di tabel
            setOnChartValueSelectedListener(object : OnChartValueSelectedListener {
                override fun onValueSelected(e: Entry?, h: Highlight?) {
                    e ?: return
                    val idx = e.x.toInt().coerceIn(0, 31)
                    // Scroll tabel ke baris yang dipilih
                    if (!showingGraph) {
                        binding.tableScroll.smoothScrollTo(0, idx * 60)
                    }
                }
                override fun onNothingSelected() {}
            })
        }
    }

    private fun updateChart(cfg: CdiConfig) {
        val entries = cfg.advanceMap.mapIndexed { i, v -> Entry(i.toFloat(), v.toFloat()) }

        // Warna gradient berdasarkan zone
        val dataSet = LineDataSet(entries, "Advance").apply {
            color = Color.parseColor("#FF5722")
            fillColor = Color.parseColor("#33FF5722")
            setDrawFilled(true)
            setDrawCircles(true)
            circleRadius = 4f
            setCircleColor(Color.parseColor("#FF5722"))
            setDrawValues(true)
            valueTextColor = Color.WHITE
            valueTextSize = 8f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float) = "${value.toInt()}°"
            }
            lineWidth = 2.5f
            mode = LineDataSet.Mode.HORIZONTAL_BEZIER
        }
        binding.chartAdvance.data = LineData(dataSet)
        binding.chartAdvance.invalidate()
    }

    private fun setupButtons() {
        binding.btnSendMap.setOnClickListener { viewModel.sendFullConfig() }
        binding.btnReset.setOnClickListener { viewModel.resetEditToDefault() }
        binding.btnRevert.setOnClickListener { viewModel.resetEditToLast() }
        binding.btnToggleView.setOnClickListener { toggleView() }
    }

    private fun observeViewModel() {
        viewModel.editConfig.observe(viewLifecycleOwner) { cfg ->
            isUpdatingFromViewModel = true
            for (i in 0 until 32) {
                editTexts[i]?.setText(cfg.advanceMap[i].toString())
            }
            isUpdatingFromViewModel = false
            updateChart(cfg)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
