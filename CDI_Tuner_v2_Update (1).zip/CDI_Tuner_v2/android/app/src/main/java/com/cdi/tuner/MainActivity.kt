package com.cdi.tuner

import android.Manifest
import android.annotation.SuppressLint
import android.os.*
import android.view.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.cdi.tuner.connection.ConnectionState
import com.cdi.tuner.connection.ConnectionType
import com.cdi.tuner.databinding.ActivityMainBinding
import com.cdi.tuner.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    val viewModel: MainViewModel by viewModels()

    // Animasi pulse untuk indikator koneksi
    private val pulseHandler = Handler(Looper.getMainLooper())
    private var pulseRunnable: Runnable? = null

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) showConnectDialog()
        else Toast.makeText(this, "Izin Bluetooth diperlukan", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupNavigation()
        setupConnectionButton()
        observeViewModel()
    }

    private fun setupNavigation() {
        val navHost = supportFragmentManager.findFragmentById(R.id.nav_host) as NavHostFragment
        val navController = navHost.navController
        binding.bottomNav.setupWithNavController(navController)
    }

    private fun setupConnectionButton() {
        binding.btnConnect.setOnClickListener {
            if (viewModel.connectionManager.isConnected) {
                AlertDialog.Builder(this)
                    .setTitle("Putuskan Koneksi?")
                    .setMessage("Yakin ingin memutuskan koneksi?")
                    .setPositiveButton("Ya") { _, _ -> viewModel.disconnect() }
                    .setNegativeButton("Tidak", null)
                    .show()
            } else {
                checkPermissionsAndConnect()
            }
        }
    }

    private fun checkPermissionsAndConnect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions.launch(arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            ))
        } else {
            showConnectDialog()
        }
    }

    @SuppressLint("MissingPermission")
    private fun showConnectDialog() {
        val options = arrayOf("🔵  Bluetooth (HC-05)", "🔌  USB OTG")
        AlertDialog.Builder(this)
            .setTitle("Pilih Koneksi")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showBluetoothDeviceDialog()
                    1 -> viewModel.connectUsb()
                }
            }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun showBluetoothDeviceDialog() {
        val devices = viewModel.getPairedDevices()
        if (devices.isEmpty()) {
            Toast.makeText(this,
                "Tidak ada perangkat Bluetooth terpasang.\nPair HC-05 dulu di Settings.",
                Toast.LENGTH_LONG).show()
            return
        }
        val names = devices.map { "${it.name}  |  ${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("🔵 Pilih HC-05")
            .setItems(names) { _, idx -> viewModel.connectBluetooth(devices[idx]) }
            .show()
    }

    // ─── Animasi pulse indicator ──────────────────────────
    private fun startPulseAnimation() {
        pulseRunnable = object : Runnable {
            var visible = true
            override fun run() {
                binding.indicatorDot.isVisible = visible
                visible = !visible
                pulseHandler.postDelayed(this, 500)
            }
        }
        pulseHandler.post(pulseRunnable!!)
    }

    private fun stopPulseAnimation() {
        pulseRunnable?.let { pulseHandler.removeCallbacks(it) }
        binding.indicatorDot.isVisible = true
    }

    private fun observeViewModel() {
        viewModel.connectionState.observe(this) { state ->
            when (state) {
                is ConnectionState.Disconnected -> {
                    stopPulseAnimation()
                    binding.indicatorDot.setColorFilter(getColor(R.color.status_disconnected))
                    binding.connectionStatus.text = "Tidak terhubung"
                    binding.connectionStatus.setTextColor(getColor(R.color.status_disconnected))
                    binding.tvConnectionType.text = ""
                    binding.btnConnect.text = "Hubungkan"
                    binding.btnConnect.setBackgroundColor(getColor(R.color.colorPrimary))
                }
                is ConnectionState.Connecting -> {
                    startPulseAnimation()
                    binding.indicatorDot.setColorFilter(getColor(R.color.status_connecting))
                    binding.connectionStatus.text = "Menghubungkan..."
                    binding.connectionStatus.setTextColor(getColor(R.color.status_connecting))
                    binding.tvConnectionType.text = when (state.type) {
                        ConnectionType.BLUETOOTH -> "🔵 Bluetooth"
                        ConnectionType.USB -> "🔌 USB OTG"
                    }
                    binding.btnConnect.text = "Batal"
                }
                is ConnectionState.Connected -> {
                    stopPulseAnimation()
                    binding.indicatorDot.setColorFilter(getColor(R.color.status_connected))
                    binding.connectionStatus.text = state.name
                    binding.connectionStatus.setTextColor(getColor(R.color.status_connected))
                    binding.tvConnectionType.text = when (state.type) {
                        ConnectionType.BLUETOOTH -> "🔵 Bluetooth"
                        ConnectionType.USB -> "🔌 USB OTG"
                    }
                    binding.btnConnect.text = "Putuskan"
                    binding.btnConnect.setBackgroundColor(getColor(R.color.status_error))
                    // Tampilkan toast konfirmasi
                    Toast.makeText(this,
                        "✅ Terhubung ke ${state.name}",
                        Toast.LENGTH_SHORT).show()
                }
                is ConnectionState.Error -> {
                    stopPulseAnimation()
                    binding.indicatorDot.setColorFilter(getColor(R.color.status_error))
                    binding.connectionStatus.text = "Error"
                    binding.connectionStatus.setTextColor(getColor(R.color.status_error))
                    binding.tvConnectionType.text = ""
                    binding.btnConnect.text = "Hubungkan"
                    binding.btnConnect.setBackgroundColor(getColor(R.color.colorPrimary))
                    Toast.makeText(this, "❌ ${state.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        viewModel.statusMessage.observe(this) { msg ->
            if (msg != null) {
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                viewModel.clearStatus()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPulseAnimation()
    }
}
