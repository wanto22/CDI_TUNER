package com.cdi.tuner.viewmodel

import android.app.Application
import android.bluetooth.BluetoothDevice
import androidx.lifecycle.*
import com.cdi.tuner.connection.ConnectionManager
import com.cdi.tuner.connection.ConnectionState
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.data.Preset
import com.cdi.tuner.data.PresetDatabase
import com.cdi.tuner.protocol.CdiProtocol
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val connectionManager = ConnectionManager(application)
    private val db = PresetDatabase.getInstance(application)

    val connectionState = connectionManager.state.asLiveData()

    private val _rpm = MutableLiveData(0)
    val rpm: LiveData<Int> = _rpm

    private val _config = MutableLiveData(CdiConfig())
    val config: LiveData<CdiConfig> = _config

    private val _editConfig = MutableLiveData(CdiConfig())
    val editConfig: LiveData<CdiConfig> = _editConfig

    private val _statusMessage = MutableLiveData<String?>()
    val statusMessage: LiveData<String?> = _statusMessage

    val presets: LiveData<List<Preset>> = db.presetDao().getAll().asLiveData()

    init {
        viewModelScope.launch {
            connectionManager.incomingLines.collect { line ->
                when (val msg = CdiProtocol.parseLine(line)) {
                    is CdiProtocol.Message.Rpm    -> _rpm.postValue(msg.value)
                    is CdiProtocol.Message.Config -> {
                        _config.postValue(msg.config)
                        _editConfig.postValue(msg.config.copy())
                        _statusMessage.postValue("✅ Config diterima dari CDI")
                    }
                    is CdiProtocol.Message.Ok  -> _statusMessage.postValue("✅ Berhasil")
                    is CdiProtocol.Message.Err -> _statusMessage.postValue("❌ Error dari CDI")
                    else -> {}
                }
            }
        }

        viewModelScope.launch {
            connectionManager.state.collect { state ->
                if (state is ConnectionState.Connected) {
                    kotlinx.coroutines.delay(600)
                    requestConfig()
                }
            }
        }
    }

    // ─── Connection ───────────────────────────────────────
    fun connectBluetooth(device: BluetoothDevice) = connectionManager.connectBluetooth(device)
    fun connectUsb() = connectionManager.connectUsb()
    fun disconnect() = connectionManager.disconnect()
    fun getPairedDevices() = connectionManager.getPairedDevices()

    // ─── CDI Commands ─────────────────────────────────────
    fun requestConfig() {
        connectionManager.send(CdiProtocol.buildGet())
    }

    fun sendFullConfig() {
        val cfg = _editConfig.value ?: return
        viewModelScope.launch {
            CdiProtocol.buildFullConfig(cfg).forEach { cmd ->
                connectionManager.send(cmd)
                kotlinx.coroutines.delay(100)
            }
            _statusMessage.value = "📤 Config dikirim ke CDI"
        }
    }

    fun sendLimiter(rpm: Int) {
        connectionManager.send(CdiProtocol.buildSetLimiter(rpm))
        connectionManager.send(CdiProtocol.buildSave())
        updateEditLimiter(rpm)
    }

    fun sendPulserAngle(deg: Int) {
        connectionManager.send(CdiProtocol.buildSetAngle(deg))
        connectionManager.send(CdiProtocol.buildSave())
        updateEditAngle(deg)
    }

    // ─── Edit Config ──────────────────────────────────────
    fun updateEditAdvanceMap(index: Int, value: Int) {
        val current = _editConfig.value ?: return
        val newMap = current.advanceMap.copyOf()
        newMap[index] = value.coerceIn(0, 45)
        _editConfig.value = current.copy(advanceMap = newMap)
    }

    fun updateEditLimiter(rpm: Int) {
        _editConfig.value = _editConfig.value?.copy(rpmLimiter = rpm)
    }

    fun updateEditAngle(deg: Int) {
        _editConfig.value = _editConfig.value?.copy(pulserAngle = deg)
    }

    fun resetEditToLast() {
        _editConfig.value = _config.value?.copy() ?: CdiConfig()
    }

    fun resetEditToDefault() {
        _editConfig.value = CdiConfig()
    }

    // ─── Load config langsung (untuk quick mode) ──────────
    fun loadConfig(config: CdiConfig) {
        _editConfig.value = config.copy()
        _statusMessage.value = "📂 Config dimuat"
    }

    // ─── Preset ───────────────────────────────────────────
    fun savePreset(name: String) {
        val cfg = _editConfig.value ?: return
        viewModelScope.launch {
            val json = JSONArray().apply { cfg.advanceMap.forEach { put(it) } }.toString()
            db.presetDao().insert(Preset(
                name = name,
                advanceMapJson = json,
                rpmLimiter = cfg.rpmLimiter,
                pulserAngle = cfg.pulserAngle
            ))
            _statusMessage.value = "💾 Preset '$name' tersimpan"
        }
    }

    fun loadPreset(preset: Preset) {
        val arr = JSONArray(preset.advanceMapJson)
        val map = IntArray(32) { arr.getInt(it) }
        _editConfig.value = CdiConfig(map, preset.rpmLimiter, preset.pulserAngle)
        _statusMessage.value = "📂 Preset '${preset.name}' dimuat"
    }

    fun deletePreset(preset: Preset) {
        viewModelScope.launch { db.presetDao().delete(preset) }
    }

    fun clearStatus() { _statusMessage.value = null }

    override fun onCleared() {
        super.onCleared()
        connectionManager.dispose()
    }
}
