package com.cdi.tuner.ui.presets

import android.os.Bundle
import android.view.*
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.*
import com.cdi.tuner.R
import com.cdi.tuner.data.CdiConfig
import com.cdi.tuner.data.Preset
import com.cdi.tuner.databinding.FragmentPresetsBinding
import com.cdi.tuner.databinding.ItemPresetBinding
import com.cdi.tuner.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

class PresetsFragment : Fragment() {

    private var _binding: FragmentPresetsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: PresetAdapter

    // ─── Mode presets bawaan ──────────────────────────────
    companion object {
        val MODE_HARIAN = CdiConfig(
            advanceMap = intArrayOf(
                0, 8, 15, 20, 24, 28, 30, 32,
                34,34, 34, 34, 34, 34, 34, 34,
                34,34, 34, 34, 34, 32, 30, 27,
                23,19, 17, 15, 15, 15, 10, 10
            ),
            rpmLimiter = 10500,
            pulserAngle = 82
        )

        val MODE_RACING = CdiConfig(
            advanceMap = intArrayOf(
                0, 5, 12, 18, 24, 30, 34, 36,
                38,40, 40, 40, 40, 40, 38, 36,
                34,32, 30, 28, 26, 24, 22, 20,
                18,15, 12, 10, 10, 10,  8,  8
            ),
            rpmLimiter = 12000,
            pulserAngle = 82
        )

        val MODE_IRIT = CdiConfig(
            advanceMap = intArrayOf(
                0, 6, 12, 16, 20, 22, 24, 26,
                28,28, 28, 28, 28, 28, 28, 28,
                28,28, 27, 26, 24, 22, 20, 18,
                16,14, 12, 10, 10, 10,  8,  8
            ),
            rpmLimiter = 9000,
            pulserAngle = 82
        )
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        FragmentPresetsBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupQuickModes()
        setupRecyclerView()
        setupSaveButton()
        observePresets()
    }

    // ─── Quick Mode Buttons ───────────────────────────────
    private fun setupQuickModes() {
        // Mode Harian
        binding.btnModeHarian.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("🏍️ Mode Harian")
                .setMessage("Advance map standar Mio 5TF.\nLimiter: 10500 RPM\n\nMuat mode ini?")
                .setPositiveButton("Muat & Kirim") { _, _ ->
                    viewModel.loadConfig(MODE_HARIAN)
                    viewModel.sendFullConfig()
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        // Mode Racing
        binding.btnModeRacing.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("🏁 Mode Racing")
                .setMessage("Advance agresif untuk performa maksimal.\nLimiter: 12000 RPM\n\n⚠️ Tidak disarankan untuk harian!\n\nMuat mode ini?")
                .setPositiveButton("Muat & Kirim") { _, _ ->
                    viewModel.loadConfig(MODE_RACING)
                    viewModel.sendFullConfig()
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        // Mode Irit
        binding.btnModeIrit.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("⛽ Mode Irit")
                .setMessage("Advance lebih konservatif untuk BBM irit.\nLimiter: 9000 RPM\n\nMuat mode ini?")
                .setPositiveButton("Muat & Kirim") { _, _ ->
                    viewModel.loadConfig(MODE_IRIT)
                    viewModel.sendFullConfig()
                }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    private fun setupRecyclerView() {
        adapter = PresetAdapter(
            onLoad = { preset ->
                viewModel.loadPreset(preset)
            },
            onSend = { preset ->
                viewModel.loadPreset(preset)
                viewModel.sendFullConfig()
            },
            onDelete = { preset ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Hapus Preset")
                    .setMessage("Hapus '${preset.name}'?")
                    .setPositiveButton("Hapus") { _, _ -> viewModel.deletePreset(preset) }
                    .setNegativeButton("Batal", null)
                    .show()
            }
        )
        binding.rvPresets.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = this@PresetsFragment.adapter
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }
    }

    private fun setupSaveButton() {
        binding.btnSavePreset.setOnClickListener {
            val input = EditText(requireContext()).apply {
                hint = "Nama preset (contoh: Harian, Racing)"
                setPadding(48, 16, 48, 16)
            }
            AlertDialog.Builder(requireContext())
                .setTitle("💾 Simpan Preset")
                .setView(input)
                .setPositiveButton("Simpan") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isNotEmpty()) viewModel.savePreset(name)
                }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    private fun observePresets() {
        viewModel.presets.observe(viewLifecycleOwner) { presets ->
            adapter.submitList(presets)
            binding.tvEmpty.visibility = if (presets.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

// ─── Adapter ──────────────────────────────────────────────
class PresetAdapter(
    private val onLoad: (Preset) -> Unit,
    private val onSend: (Preset) -> Unit,
    private val onDelete: (Preset) -> Unit
) : ListAdapter<Preset, PresetAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemPresetBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemPresetBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val preset = getItem(position)
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        holder.binding.apply {
            tvPresetName.text = preset.name
            tvPresetInfo.text = "Limiter: ${preset.rpmLimiter} RPM • Angle: ${preset.pulserAngle}°"
            tvPresetDate.text = fmt.format(Date(preset.createdAt))
            btnLoad.setOnClickListener { onLoad(preset) }
            btnSend.setOnClickListener { onSend(preset) }
            btnDelete.setOnClickListener { onDelete(preset) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Preset>() {
            override fun areItemsTheSame(a: Preset, b: Preset) = a.id == b.id
            override fun areContentsTheSame(a: Preset, b: Preset) = a == b
        }
    }
}
